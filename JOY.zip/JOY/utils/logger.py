from datetime import datetime
import logging
import os
from typing import Dict

# ============================================================
# LOGGING CONFIGURATION & CONSTANTS
# ============================================================
LOG_DIR = "LOG"
LOG_FILE = os.path.join(LOG_DIR, "joy.log")
LOG_FORMAT = "%(asctime)s | %(levelname)-7s | %(name)s | %(message)s"
LOG_DATEFMT = "%Y-%m-%d %H:%M:%S"

# Explicit log level mapping for noisy third-party libraries
NOISY_LOGGERS: Dict[str, int] = {
    "httpx": logging.WARNING,
    "httpcore": logging.WARNING,
    "urllib3": logging.WARNING,
    "huggingface_hub": logging.WARNING,
    "transformers": logging.ERROR,
    "comtypes": logging.WARNING,
    "comtypes.client._code_cache": logging.WARNING,
    "torch": logging.WARNING,
    "sentencepiece": logging.WARNING,
    "asyncio": logging.WARNING,
}


def setup_logger() -> logging.Logger:
    """
    Initializes centralized file logging with clean formatting,
    ensures proper file handler cleanup, and suppresses noisy dependencies.
    """
    # 1. Performance & offline configuration
    os.environ["HF_HUB_OFFLINE"] = "1"
    os.environ["TRANSFORMERS_VERBOSITY"] = "error"
    os.environ["TOKENIZERS_PARALLELISM"] = "false"

    # 2. Ensure log directory exists
    os.makedirs(LOG_DIR, exist_ok=True)

    root_logger = logging.getLogger()
    root_logger.setLevel(logging.INFO)

    # 3. Cleanly close and remove existing handlers to prevent duplicate output/leaks
    for handler in root_logger.handlers[:]:
        handler.close()
        root_logger.removeHandler(handler)

    # 4. Attach UTF-8 timestamped file handler
    file_handler = logging.FileHandler(LOG_FILE, mode="a", encoding="utf-8")
    formatter = logging.Formatter(LOG_FORMAT, datefmt=LOG_DATEFMT)
    file_handler.setFormatter(formatter)
    root_logger.addHandler(file_handler)

    # 5. Suppress noisy third-party logs
    for logger_name, log_level in NOISY_LOGGERS.items():
        logging.getLogger(logger_name).setLevel(log_level)

    # 6. Session start banner
    start_time = datetime.now().strftime(LOG_DATEFMT)
    banner_logger = logging.getLogger("root")
    banner_logger.info("=" * 70)
    banner_logger.info(f"JOY SESSION STARTED AT {start_time}")
    banner_logger.info("=" * 70)

    return root_logger