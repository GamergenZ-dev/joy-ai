import logging
import os
import re
import threading
import time

import config

from core.router import ThreeTierRouter
from speech.stt import STT
from speech.tts import StreamingTTS


# ============================================================
# WINDOWS CONSOLE
# ============================================================

os.system("")

logger = logging.getLogger(__name__)


# ============================================================
# LLM OUTPUT CLEANING
# ============================================================

TIME_PATTERN = re.compile(
    r"(\b\d{1,2}):(\d{2})\b"
)

CLEAN_LLM_REGEX = re.compile(
    r"[^a-zA-Z0-9+\-/*\s:,.?!']"
)

MULTIPLE_SPACES = re.compile(
    r"\s+"
)


def clean_llm_token(
    text: str,
) -> str:
    """
    Clean an LLM token/chunk before terminal display
    and TTS playback.

    Keeps:
        letters
        numbers
        normal punctuation
        apostrophes
        math symbols
    """

    if not text:
        return ""

    # Prevent SAPI from treating "12:30" as an awkward
    # punctuation sequence.
    text = TIME_PATTERN.sub(
        r"\1 \2",
        text,
    )

    return CLEAN_LLM_REGEX.sub(
        "",
        text,
    )


def calculate_words_per_sec(
    text: str,
    duration_sec: float,
) -> int:
    """
    Existing metric preserved.
    """

    if duration_sec <= 0.05:
        return 0

    words = len(
        text.strip().split()
    )

    if words <= 0:
        return 0

    return max(
        1,
        int(
            round(
                words / duration_sec
            )
        ),
    )


# ============================================================
# ROUTER / TTS
# ============================================================

router = ThreeTierRouter()

tts = StreamingTTS()

# Tier 1 needs the TTS reference for any commands that
# interact with speech playback.
if (
    hasattr(router, "tier1")
    and hasattr(
        router.tier1,
        "set_tts",
    )
):
    router.tier1.set_tts(
        tts
    )


# ============================================================
# ASSISTANT STATE
# ============================================================

is_awake = not config.WAKE_CONFIG[
    "start_in_sleep"
]


# ============================================================
# OUTPUT HELPERS
# ============================================================

def _print_user_text(
    text: str,
) -> None:
    print(
        f"\r\033[K"
        f"\033[32m[You Said]: "
        f"{text}"
        f"\033[0m",
        flush=True,
    )


def _record_turn(
    user_text: str,
    response_text: str,
) -> None:
    """
    Preserve conversation history support without forcing
    the router to expose a specific implementation.
    """

    try:

        if (
            hasattr(router, "llm")
            and hasattr(
                router.llm,
                "record_turn",
            )
        ):
            router.llm.record_turn(
                user_text,
                response_text,
            )

    except Exception as exc:
        logger.debug(
            f"Conversation history recording failed: {exc}"
        )


# ============================================================
# PARTIAL SPEECH
# ============================================================

def handle_partial_speech(
    text: str,
):
    """
    Displays the current STT partial while JOY is awake.
    """

    if not is_awake:
        return

    if text and text.strip():

        print(
            f"\r\033[K"
            f"\033[36m[💬 Live]: "
            f"{text}"
            f"\033[0m",
            end="",
            flush=True,
        )


# ============================================================
# WAKE TRIGGER
# ============================================================

def _match_wake_trigger(
    text: str,
    wake_triggers,
):
    """
    Return the matching wake phrase.
    """

    clean_text = text.lower().strip()

    for trigger in wake_triggers:

        trigger = trigger.lower().strip()

        if (
            clean_text == trigger
            or clean_text.startswith(
                trigger + " "
            )
        ):
            return trigger

    return None


# ============================================================
# SLEEP TRIGGER
# ============================================================

def _matches_sleep_trigger(
    text: str,
    sleep_triggers,
) -> bool:
    """
    Check whether the transcript begins with a configured
    sleep command.
    """

    clean_text = text.lower().strip()

    for command in sleep_triggers:

        command = command.lower().strip()

        if (
            clean_text == command
            or clean_text.startswith(
                command + " "
            )
        ):
            return True

    return False


# ============================================================
# RESPONSE PROCESSOR
# ============================================================

def process_and_respond(
    text: str,
):
    """
    Main JOY orchestration:

        STT mute
            ↓
        wake/sleep check
            ↓
        router
            ↓
        Tier 1/2 static response
        OR
        Tier 3/4 LLM streaming
            ↓
        TTS
            ↓
        STT unmute
    """

    global is_awake

    try:

        # ========================================================
        # 1. MUTE STT
        # ========================================================

        services.stt.mute()

        clean_user_text = (
            text.lower().strip()
        )

        wake_triggers = (
            config.WAKE_CONFIG[
                "wake_commands"
            ]
        )

        sleep_triggers = (
            config.WAKE_CONFIG[
                "sleep_commands"
            ]
        )

        # ========================================================
        # 2. SLEEP MODE
        # ========================================================

        if not is_awake:

            matched_wake = (
                _match_wake_trigger(
                    clean_user_text,
                    wake_triggers,
                )
            )

            # Ignore everything until wake phrase.
            if not matched_wake:
                return

            # Wake.
            is_awake = True

            _print_user_text(
                text
            )

            # Handle:
            #
            # "hey joy"
            #
            # and:
            #
            # "hey joy open chrome"
            #
            remaining_prompt = (
                clean_user_text[
                    len(matched_wake):
                ].strip()
            )

            # ----------------------------------------------------
            # Wake only
            # ----------------------------------------------------

            if not remaining_prompt:

                ack_response = (
                    "Yes? I'm listening."
                )

                print(
                    f"\033[35m"
                    f"[JOY (Wake)]:"
                    f"\033[0m "
                    f"{ack_response}\n",
                    flush=True,
                )

                tts.speak(
                    ack_response
                )

                tts.speech_queue.join()

                logger.info(
                    f"[JOY (Wake)]: "
                    f"{ack_response}\n"
                )

                return

            # ----------------------------------------------------
            # Wake + command in same utterance
            # ----------------------------------------------------

            text = remaining_prompt

        # ========================================================
        # 3. SLEEP COMMAND
        # ========================================================

        elif _matches_sleep_trigger(
            clean_user_text,
            sleep_triggers,
        ):

            is_awake = False

            _print_user_text(
                text
            )

            sleep_response = (
                "Going to sleep. "
                "call me, when you need me."
            )

            print(
                f"\033[35m"
                f"[JOY (Sleep)]:"
                f"\033[0m "
                f"{sleep_response}\n",
                flush=True,
            )

            tts.speak(
                sleep_response
            )

            tts.speech_queue.join()

            logger.info(
                f"[JOY (Sleep)]: "
                f"{sleep_response}\n"
            )

            return

        # ========================================================
        # 4. NORMAL ROUTING
        # ========================================================

        _print_user_text(
            text
        )

        tier, response_data, is_stream, latency_ms = (
            router.process(
                text
            )
        )

        # ========================================================
        # 5. TIER 3 / 4 STREAMING
        # ========================================================

        if is_stream:

            stream_gen, stream_start = (
                response_data
            )

            ttft_ms = 0.0
            first_token_received = False

            collected_tokens = []

            tier_label = (
                f"JOY (Tier {tier})"
            )

            # Header.
            print(
                f"\033[35m"
                f"[{tier_label}]:"
                f"\033[0m ",
                end="",
                flush=True,
            )

            # ----------------------------------------------------
            # LLM -> TTS streaming adapter
            # ----------------------------------------------------

            def stream_and_clean_tokens():

                nonlocal ttft_ms, first_token_received

                for token in stream_gen:

                    if token is None:
                        continue

                    # First token = TTFT measurement.
                    if not first_token_received:

                        ttft_ms = (
                            time.perf_counter()
                            - stream_start
                        ) * 1000.0

                        first_token_received = True

                    clean_chunk = (
                        clean_llm_token(
                            token
                        )
                    )

                    if not clean_chunk:
                        continue

                    # Terminal live output.
                    print(
                        f"\033[35m"
                        f"{clean_chunk}"
                        f"\033[0m",
                        end="",
                        flush=True,
                    )

                    collected_tokens.append(
                        clean_chunk
                    )

                    # Immediately feed the chunk into TTS.
                    yield clean_chunk

            # ====================================================
            # STREAMING TTS
            # ====================================================

            tts_start = (
                time.perf_counter()
            )

            tts.stream_llm_response(
                stream_and_clean_tokens()
            )

            # Wait for complete response playback.
            tts.speech_queue.join()

            tts_duration = (
                time.perf_counter()
                - tts_start
            )

            total_stream_ms = (
                time.perf_counter()
                - stream_start
            ) * 1000.0

            # Combine cleaned tokens for history/logging.
            full_response = (
                MULTIPLE_SPACES.sub(
                    " ",
                    "".join(
                        collected_tokens
                    ),
                ).strip()
            )

            tts_wps = (
                calculate_words_per_sec(
                    full_response,
                    tts_duration,
                )
            )

            metrics = (
                f"("
                f"{ttft_ms:.1f}ms TTFT | "
                f"{total_stream_ms:.1f}ms Total | "
                f"TTS {tts_wps} Words P/s"
                f")"
            )

            print(
                f" \033[90m"
                f"{metrics}"
                f"\033[0m\n",
                flush=True,
            )

            logger.info(
                f"[{tier_label}]: "
                f"{full_response} "
                f"{metrics}\n"
            )

            _record_turn(
                text,
                full_response,
            )

        # ========================================================
        # 6. TIER 1 / 2 STATIC RESPONSE
        # ========================================================

        else:

            if response_data:

                clean_response = (
                    clean_llm_token(
                        response_data
                    )
                )

                clean_response = (
                    MULTIPLE_SPACES.sub(
                        " ",
                        clean_response,
                    ).strip()
                )

                print(
                    f"\033[35m"
                    f"[JOY (Tier {tier})]: "
                    f"{clean_response}"
                    f"\033[0m",
                    end="",
                    flush=True,
                )

                # =================================================
                # STATIC TTS
                # =================================================

                tts_start = (
                    time.perf_counter()
                )

                tts.speak(
                    clean_response
                )

                tts.speech_queue.join()

                tts_duration = (
                    time.perf_counter()
                    - tts_start
                )

                tts_wps = (
                    calculate_words_per_sec(
                        clean_response,
                        tts_duration,
                    )
                )

                metrics = (
                    f"("
                    f"{latency_ms:.1f}ms | "
                    f"TTS {tts_wps} Words P/s"
                    f")"
                )

                print(
                    f" \033[90m"
                    f"{metrics}"
                    f"\033[0m\n",
                    flush=True,
                )

                logger.info(
                    f"[JOY (Tier {tier})]: "
                    f"{clean_response} "
                    f"{metrics}\n"
                )

                _record_turn(
                    text,
                    clean_response,
                )

    except Exception as exc:

        logger.error(
            f"Error processing response "
            f"in Services: {exc}\n",
            exc_info=True,
        )

        print(
            f"\n\033[31m"
            f"[JOY Error]: {exc}"
            f"\033[0m\n",
            flush=True,
        )

    finally:

        # Give the room a short cooldown so JOY doesn't
        # immediately hear its own voice.
        cooldown = (
            config.WAKE_CONFIG[
                "sleep_cooldown"
            ]
        )

        services.stt.unmute(
            cooldown_seconds=cooldown
        )


# ============================================================
# FINAL SPEECH CALLBACK
# ============================================================

def handle_final_speech(
    text: str,
):
    """
    Execute recognized speech in the background so the
    STT/recognizer thread never blocks on router/TTS work.
    """

    clean_text_value = (
        text.strip()
        if text
        else ""
    )

    if (
        not clean_text_value
        or services.stt.is_muted()
    ):
        return

    processing_thread = threading.Thread(
        target=process_and_respond,
        args=(clean_text_value,),
        daemon=True,
        name="JOY-Response-Worker",
    )

    processing_thread.start()


# ============================================================
# SERVICES COORDINATOR
# ============================================================

class Services:
    """
    Central JOY service coordinator.
    """

    def __init__(self):

        logger.info(
            "Initializing JOY Services..."
        )

        self.router = router
        self.tts = tts

        self.stt = STT(
            on_partial_text=(
                handle_partial_speech
            ),
            on_final_text=(
                handle_final_speech
            ),
        )

        self.stt.start()

        if not is_awake:

            print(
                "\n\033[90m"
                "[JOY Sleeping]: "
                "Say 'Hey Joy' to activate."
                "\033[0m",
                flush=True,
            )

        logger.info(
            "JOY Services initialized successfully."
        )


# ============================================================
# SINGLETON
# ============================================================

services = Services()