import logging
import time
from typing import Any, Tuple

from ai.llm import LocalLLM
from tools.tier1 import Tier1Handler
from tools.tier2 import Tier2Handler
from tools.tier3 import Tier3Handler
from tools.tier4 import Tier4Handler

logger = logging.getLogger(__name__)


class ThreeTierRouter:
    """
    Four-layer hierarchical router: deterministic commands first,
    then tool-augmented reasoning, then general conversation.
    """

    def __init__(self):
        self.llm = LocalLLM()
        self.tier1 = Tier1Handler()
        self.tier2 = Tier2Handler(self.llm)
        self.tier4 = Tier4Handler(self.llm)
        self.tier3 = Tier3Handler(self.llm)

    def process(self, text: str) -> Tuple[int, Any, bool, float]:
        """
        Evaluates: Tier 1 -> Tier 2 -> Tier 4 -> Tier 3.
        Returns: (tier_number, response_or_generator, is_stream, latency_ms)
        """
        # ============================================================
        # TIER 1: DETERMINISTIC SYSTEM APPS (<5ms)
        # ============================================================
        t1_start = time.perf_counter()
        handled, response = self.tier1.execute(text)
        t1_elapsed = (time.perf_counter() - t1_start) * 1000.0

        if handled:
            return 1, response, False, t1_elapsed

        # ============================================================
        # TIER 2: DETERMINISTIC OS INTENTS
        # ============================================================
        # Must run before Tier 4 so cheap commands never pay telemetry/LLM cost.
        t2_start = time.perf_counter()
        handled, response = self.tier2.execute(text)
        t2_elapsed = (time.perf_counter() - t2_start) * 1000.0

        if handled:
            return 2, response, False, t2_elapsed

        # ============================================================
        # TIER 4: TOOL-AUGMENTED CONVERSATIONAL REASONING
        # ============================================================
        t4_start = time.perf_counter()
        tier4_match = self.tier4.check_and_gather_context(text)
        if tier4_match:
            _, tool_context = tier4_match
            stream_gen = self.tier4.execute_stream(text, tool_context)
            return 4, (stream_gen, t4_start), True, 0.0

        # ============================================================
        # TIER 3: GENERAL CONVERSATION & MEMORY
        # ============================================================
        t3_start = time.perf_counter()
        stream_gen = self.tier3.execute_stream(text)
        return 3, (stream_gen, t3_start), True, 0.0