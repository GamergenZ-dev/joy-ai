import logging
import os
import sys
import time
import config
from core.services import services

# Enable ANSI escape sequences on Windows terminals
os.system("")

logger = logging.getLogger(__name__)


# ============================================================
# TERMINAL UI FORMATTING & BANNERS
# ============================================================

class TerminalUI:
    RESET = "\033[0m"
    BOLD = "\033[1m"
    CYAN = "\033[36m"
    GREEN = "\033[32m"
    YELLOW = "\033[33m"
    RED = "\033[31m"
    GRAY = "\033[90m"

    @classmethod
    def print_start_banner(cls):
        stt_model = config.STT_CONFIG["model"]
        llm_model = config.LLM_CONFIG["model"]

        print(
            f"{cls.BOLD}{cls.CYAN}======================================================================{cls.RESET}"
        )
        print(
            f"{cls.BOLD}{cls.GREEN}                      🟢 JOY AI ASSISTANT ONLINE                      {cls.RESET}"
        )
        print(
            f"{cls.BOLD}{cls.CYAN}======================================================================{cls.RESET}"
        )
        print(
            f"{cls.GRAY}Engine : {stt_model} (INT8 CPU Quantized){cls.RESET}"
        )
        print(
            f"{cls.GRAY}Logic  : 4-Tier System + Ollama ({llm_model}){cls.RESET}"
        )
        print(
            f"{cls.GRAY}Status : Active & Listening on Default Microphone...{cls.RESET}"
        )
        print(
            f"\n{cls.YELLOW}▶ Speak into your microphone. Press Ctrl+C to exit.{cls.RESET}"
        )
        print(
            f"{cls.BOLD}{cls.CYAN}======================================================================{cls.RESET}\n",
            flush=True,
        )

    @classmethod
    def print_stop_banner(cls):
        print(
            f"\n{cls.BOLD}{cls.RED}======================================================================{cls.RESET}"
        )
        print(
            f"{cls.BOLD}{cls.YELLOW}                      🛑 JOY AI ASSISTANT STOPPED                     {cls.RESET}"
        )
        print(
            f"{cls.BOLD}{cls.RED}======================================================================{cls.RESET}"
        )
        print(f"{cls.GRAY}Session Status : Closed successfully{cls.RESET}")
        print(f"{cls.GRAY}Logs Saved     : LOG/joy.log{cls.RESET}")
        print(
            f"{cls.BOLD}{cls.RED}======================================================================{cls.RESET}\n",
            flush=True,
        )


# ============================================================
# MAIN ASSISTANT CONTROLLER
# ============================================================

class Assistant:
    def __init__(self):
        logger.info("Initializing JOY Assistant...")
        self.services = services

    def start(self):
        """Starts STT microphone listener and displays start banner."""
        if hasattr(self.services, "stt") and not getattr(self.services.stt, "running", False):
            self.services.stt.start()
        logger.info("JOY Assistant started. Listening...\n")
        TerminalUI.print_start_banner()

    def stop(self):
        """Stops STT microphone stream, cleans up TTS queue, and displays stop banner."""
        if hasattr(self.services, "stt"):
            self.services.stt.stop()
        if hasattr(self.services, "tts") and hasattr(self.services.tts, "shutdown"):
            self.services.tts.shutdown()
        logger.info("JOY Assistant stopped.")
        TerminalUI.print_stop_banner()

    def run(self):
        """Main lifecycle execution loop with graceful interrupt handling."""
        self.start()
        try:
            while True:
                time.sleep(0.1)
        except KeyboardInterrupt:
            logger.info("KeyboardInterrupt received.")
        finally:
            self.stop()