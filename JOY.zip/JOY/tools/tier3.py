# ==============================================================================
# Imports
# ==============================================================================

# Standard Library Imports
import logging
from typing import Generator

# Local / Application Imports
from ai.llm import LocalLLM

# ==============================================================================
# Global Configuration & Initialization
# ==============================================================================

logger = logging.getLogger(__name__)

# ==============================================================================
# Tier 3: Conversational Streaming Handler
# ==============================================================================

class Tier3Handler:
    """
    Tier 3: General Conversational Voice Q&A.
    Streams contextual LLM responses with unified memory.
    """

    # --------------------------------------------------------------------------
    # Initialization
    # --------------------------------------------------------------------------

    def __init__(self, llm: LocalLLM):
        self.llm = llm

    # --------------------------------------------------------------------------
    # Execution & Response Generation
    # --------------------------------------------------------------------------

    def execute(self, text: str) -> str:
        """Static conversational response fallback."""
        if hasattr(self.llm, "generate_speech_response"):
            return self.llm.generate_speech_response(text)
        # Fallback: Drain stream into full response string
        return "".join(self.llm.generate_speech_response_stream(text)).strip()

    def execute_stream(self, text: str) -> Generator[str, None, None]:
        """Streams conversation tokens directly from the LLM engine."""
        return self.llm.generate_speech_response_stream(text)