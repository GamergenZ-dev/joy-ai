# ==============================================================================
# Imports
# ==============================================================================

import ctypes
from ctypes import wintypes
import logging
import os
import re
import shutil
import subprocess
from typing import Callable, Dict, List, Optional, Tuple
import webbrowser

# ==============================================================================
# Logger & Win32 API Definitions / Constants
# ==============================================================================

logger = logging.getLogger(__name__)

# Window & Message Constants
WM_CLOSE = 0x0010
SW_MINIMIZE = 6
SW_RESTORE = 9
SW_MAXIMIZE = 3

# Virtual Key Codes
VK_LWIN = 0x5B
VK_SHIFT = 0x10
VK_M = 0x4D
VK_D = 0x44
KEYEVENTF_KEYUP = 0x0002

# Win32 DLL & Callback Types
user32 = ctypes.windll.user32
WNDENUMPROC = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

# ==============================================================================
# Pre-Compiled Command Triggers
# ==============================================================================

# ------------------------------------------------------------------------------
# Window & Application Actions
# ------------------------------------------------------------------------------

RE_OPEN_TRIGGER = re.compile(
    r"\b(?:open|launch|start|run)\b",
    re.IGNORECASE,
)

RE_CLOSE_TRIGGER = re.compile(
    r"\b(?:close|kill|exit|quit)\b",
    re.IGNORECASE,
)

RE_MINIMIZE_TRIGGER = re.compile(
    r"\b(?:minimize|minimise|hide)\b",
    re.IGNORECASE,
)

RE_MAXIMIZE_TRIGGER = re.compile(
    r"\b(?:maximize|maximise|enlarge|full\s+screen)\b",
    re.IGNORECASE,
)

RE_RESTORE_TRIGGER = re.compile(
    r"\b(?:restore|unminimize|unminimise)\b",
    re.IGNORECASE,
)

RE_MIN_ALL_TRIGGER = re.compile(
    r"\b(?:minimize|minimise)\s+(?:all|everything)(?:\s+windows?)?\b|\bminimize\s+everything\b",
    re.IGNORECASE,
)

RE_SHOW_DESKTOP_TRIGGER = re.compile(
    r"\b(?:show|display)\s+(?:the\s+)?(?:desktop|desk\s+top|disco\s+top|discotop|deskutop)\b",
    re.IGNORECASE,
)

RE_RESTORE_ALL_TRIGGER = re.compile(
    r"\brestore\s+(?:all|everything)(?:\s+windows?)?\b|\brestore\s+all\s+windows\b",
    re.IGNORECASE,
)

# ------------------------------------------------------------------------------
# System Utilities & Controls
# ------------------------------------------------------------------------------

RE_LOCK_TRIGGER = re.compile(
    r"\b(?:lock|lock\s+the)\s+(?:pc|computer|windows)\b|\block\s+screen\b",
    re.IGNORECASE,
)

RE_TASK_MANAGER_TRIGGER = re.compile(
    r"\b(?:(?:open|launch|start)\s+)?task\s+manager\b",
    re.IGNORECASE,
)

RE_SETTINGS_TRIGGER = re.compile(
    r"\b(?:(?:open|launch|start)\s+)?(?:windows\s+)?settings\b",
    re.IGNORECASE,
)

RE_DEVICE_MANAGER_TRIGGER = re.compile(
    r"\b(?:(?:open|launch|start)\s+)?device\s+manager\b",
    re.IGNORECASE,
)

RE_CONTROL_PANEL_TRIGGER = re.compile(
    r"\b(?:(?:open|launch|start)\s+)?control\s+panel\b",
    re.IGNORECASE,
)

RE_DOWNLOADS_TRIGGER = re.compile(
    r"\b(?:open|show)\s+(?:my\s+)?downloads?\b",
    re.IGNORECASE,
)

RE_DOCUMENTS_TRIGGER = re.compile(
    r"\b(?:open|show)\s+(?:my\s+)?documents?\b",
    re.IGNORECASE,
)

# ------------------------------------------------------------------------------
# Window Context & Directives
# ------------------------------------------------------------------------------

RE_ACTIVE_WINDOW = re.compile(
    r"\b(?:this|current|active)\s+window\b|\bwindow\s+itself\b",
    re.IGNORECASE,
)

STOP_COMMANDS = {"stop", "pause"}


# ==============================================================================
# Tier 1 Handler
# ==============================================================================

class Tier1Handler:
    """
    Ultra-fast deterministic command layer.

    Handles:
        - application and website launch
        - application and website close
        - explicit foreground-window close
        - smart window minimize/maximize/restore
        - desktop controls
        - common Windows utilities
        - instant stop

    Unknown open/close targets are consumed here and do NOT
    fall through to Tier 3.
    """

    # ==========================================================================
    # Initialization
    # ==========================================================================

    def __init__(self, tts_instance=None):
        self.tts = tts_instance

        # ----------------------------------------------------------------------
        # Locate browser executables once at startup.
        # ----------------------------------------------------------------------
        self.chrome_exe = self._find_executable(
            names=["chrome.exe", "chrome"],
            candidate_paths=[
                r"C:\Program Files\Google\Chrome\Application\chrome.exe",
                r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
                os.path.expandvars(r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"),
            ],
        )

        self.edge_exe = self._find_executable(
            names=["msedge.exe", "msedge"],
            candidate_paths=[
                r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
                r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
                os.path.expandvars(r"%LOCALAPPDATA%\Microsoft\Edge\Application\msedge.exe"),
            ],
        )

        self.default_browser = self.chrome_exe or self.edge_exe

        # ----------------------------------------------------------------------
        # Websites / PWAs:
        # key -> (URL, Display Name, Window Title Key)
        # ----------------------------------------------------------------------
        self.sites: Dict[str, Tuple[str, str, str]] = {
            "chatgpt": ("https://chatgpt.com", "ChatGPT", "chatgpt"),
            "gemini": ("https://gemini.google.com", "Gemini", "gemini"),
            "whatsapp": ("https://web.whatsapp.com", "WhatsApp", "whatsapp"),
            "instagram": ("https://www.instagram.com", "Instagram", "instagram"),
            "youtube": ("https://www.youtube.com", "YouTube", "youtube"),
            "google": ("https://www.google.com", "Google", "google"),
            "github": ("https://github.com", "GitHub", "github"),
            "spotify": ("https://open.spotify.com", "Spotify", "spotify"),
            "reddit": ("https://www.reddit.com", "Reddit", "reddit"),
            "twitter": ("https://x.com", "X", "x"),
            "x": ("https://x.com", "X", "x"),
            "gmail": ("https://mail.google.com", "Gmail", "gmail"),
            "linkedin": ("https://www.linkedin.com", "LinkedIn", "linkedin"),
            "netflix": ("https://www.netflix.com", "Netflix", "netflix"),
        }

        # ----------------------------------------------------------------------
        # Local applications:
        # key -> (Launch Function, Display Name, Process Name, Window Title Key)
        # ----------------------------------------------------------------------
        self.local_apps: Dict[str, Tuple[Callable, str, str, str]] = {
            "chrome": (self._launch_chrome, "Google Chrome", "chrome.exe", "chrome"),
            "google chrome": (self._launch_chrome, "Google Chrome", "chrome.exe", "chrome"),
            "edge": (self._launch_edge, "Microsoft Edge", "msedge.exe", "edge"),
            "microsoft edge": (self._launch_edge, "Microsoft Edge", "msedge.exe", "edge"),
            "notepad": (lambda: subprocess.Popen(["notepad.exe"]), "Notepad", "notepad.exe", "notepad"),
            "calculator": (lambda: subprocess.Popen(["calc.exe"]), "Calculator", "CalculatorApp.exe", "calculator"),
            "calc": (lambda: subprocess.Popen(["calc.exe"]), "Calculator", "CalculatorApp.exe", "calculator"),
            "cmd": (lambda: subprocess.Popen(["cmd.exe"]), "Command Prompt", "cmd.exe", "cmd"),
            "terminal": (lambda: subprocess.Popen(["wt.exe"]), "Windows Terminal", "WindowsTerminal.exe", "terminal"),
            "file explorer": (lambda: subprocess.Popen(["explorer.exe"]), "File Explorer", "explorer.exe", "explorer"),
            "minecraft": (lambda: self._launch_app_by_command("minecraft"), "Minecraft", "Minecraft.exe", "minecraft"),
        }

        # ----------------------------------------------------------------------
        # Spoken aliases
        # ----------------------------------------------------------------------
        self.aliases: Dict[str, str] = {
            "chat gpt": "chatgpt",
            "chat g p t": "chatgpt",
            "gpt": "chatgpt",
            "g p t": "chatgpt",
            "linked in": "linkedin",
            "red it": "reddit",
            "read it": "reddit",
            "you tube": "youtube",
            "whats app": "whatsapp",
            "task mgr": "task manager",
            "device mgr": "device manager",
            # Desktop
            "desk top": "desktop",
            "deskto p": "desktop",
            "disco top": "desktop",
            "discotop": "desktop",
            "deskutop": "desktop",
            # Calculator
            "calci": "calculator",
            "calcium": "calculator",
            "calcular": "calculator",
            "calc": "calculator",
            # Minecraft
            "mine craft": "minecraft",
            # Browsers
            "micro soft edge": "microsoft edge",
            # File Explorer
            "files explorer": "file explorer",
        }

        # ----------------------------------------------------------------------
        # Compiled application and site regex patterns
        # ----------------------------------------------------------------------
        self._compiled_local_apps = [
            (
                re.compile(rf"\b{re.escape(key)}\b", re.IGNORECASE),
                launch_fn,
                display_name,
                process_name,
                window_title,
            )
            for key, (launch_fn, display_name, process_name, window_title) in sorted(
                self.local_apps.items(),
                key=lambda item: len(item[0]),
                reverse=True,
            )
        ]

        self._compiled_sites = [
            (
                re.compile(rf"\b{re.escape(key)}\b", re.IGNORECASE),
                url,
                display_name,
                window_title,
            )
            for key, (url, display_name, window_title) in sorted(
                self.sites.items(),
                key=lambda item: len(item[0]),
                reverse=True,
            )
        ]

    # ==========================================================================
    # TTS
    # ==========================================================================

    def set_tts(self, tts_instance):
        self.tts = tts_instance

    # ==========================================================================
    # Executable Discovery
    # ==========================================================================

    @staticmethod
    def _find_executable(names: List[str], candidate_paths: List[str]) -> Optional[str]:
        for name in names:
            path = shutil.which(name)
            if path:
                return path

        for path in candidate_paths:
            if os.path.exists(path):
                return path

        return None

    # ==========================================================================
    # Application & Browser Launchers
    # ==========================================================================

    def _launch_chrome(self):
        if self.chrome_exe:
            subprocess.Popen([self.chrome_exe])
        else:
            subprocess.Popen(["cmd", "/c", "start", "", "chrome"])

    def _launch_edge(self):
        if self.edge_exe:
            subprocess.Popen([self.edge_exe])
        else:
            subprocess.Popen(["cmd", "/c", "start", "", "msedge"])

    def _open_url(self, url: str):
        if self.default_browser:
            subprocess.Popen([self.default_browser, f"--app={url}"])
        else:
            webbrowser.open(url)

    # ==========================================================================
    # Text Normalization
    # ==========================================================================

    def _normalize_text(self, text: str) -> str:
        text_lower = re.sub(r"\s+", " ", text.lower().strip())
        for phrase, clean_key in sorted(
            self.aliases.items(),
            key=lambda item: len(item[0]),
            reverse=True,
        ):
            text_lower = re.sub(
                rf"\b{re.escape(phrase)}\b",
                clean_key,
                text_lower,
            )
        return text_lower

    # ==========================================================================
    # Target Extraction
    # ==========================================================================

    def _extract_target(self, text: str, trigger: re.Pattern) -> Optional[str]:
        """
        Extract the target after a command such as:
            open youtube
            close chrome
            maximize this window
        """
        remainder = trigger.sub(" ", text, count=1)
        remainder = RE_ACTIVE_WINDOW.sub("this window", remainder)
        remainder = re.sub(r"\b(?:the|my)\b", " ", remainder)
        remainder = re.sub(r"\b(?:window|windows|screen|app|application|program)\b", " ", remainder)
        remainder = re.sub(r"\s+", " ", remainder).strip()
        return remainder or None

    # ==========================================================================
    # Window Inspection
    # ==========================================================================

    def _get_window_text(self, hwnd: int) -> str:
        length = user32.GetWindowTextLengthW(hwnd)
        if length <= 0:
            return ""

        buffer = ctypes.create_unicode_buffer(length + 1)
        user32.GetWindowTextW(hwnd, buffer, length + 1)
        return buffer.value

    def _find_windows(self, title_keyword: str) -> List[int]:
        """Return visible top-level windows whose title contains the target keyword."""
        target = title_keyword.lower().strip()
        if not target:
            return []

        found: List[int] = []

        def enum_handler(hwnd, _):
            if user32.IsWindowVisible(hwnd):
                title = self._get_window_text(hwnd)
                if title and target in title.lower():
                    found.append(hwnd)
            return True

        user32.EnumWindows(WNDENUMPROC(enum_handler), 0)
        return found

    def _resolve_window_target(self, target: Optional[str]) -> Optional[str]:
        """
        Resolve a spoken target to a known app/site.
        Unknown targets are retained so that window title lookup can still be attempted.
        """
        if not target:
            return None

        target = self._normalize_text(target).strip()
        if not target or target in {"this", "current", "active", "this window"}:
            return None

        known = list(self.local_apps) + list(self.sites)
        matches = [key for key in known if re.search(rf"\b{re.escape(key)}\b", target, re.IGNORECASE)]
        if matches:
            return max(matches, key=len)

        cleaned = re.sub(r"^(?:the\s+)?(?:app|application|program)\s+", "", target, flags=re.IGNORECASE).strip()
        if cleaned:
            matches = [key for key in known if re.search(rf"\b{re.escape(key)}\b", cleaned, re.IGNORECASE)]
            if matches:
                return max(matches, key=len)

        return cleaned or target

    # ==========================================================================
    # Window Action
    # ==========================================================================

    def _window_action(self, action: int, target_keyword: Optional[str] = None) -> bool:
        """Apply a ShowWindow action to an explicit target or the foreground window."""
        if (
            not target_keyword
            or RE_ACTIVE_WINDOW.search(target_keyword)
            or target_keyword in {"this", "current", "active"}
        ):
            hwnd = user32.GetForegroundWindow()
            handles = [hwnd] if hwnd else []
        else:
            handles = self._find_windows(target_keyword)

        success = False
        for hwnd in handles:
            if hwnd and user32.IsWindow(hwnd):
                user32.ShowWindow(hwnd, action)
                success = True

        return success

    # ==========================================================================
    # Close Window
    # ==========================================================================

    def _close_window(self, target_keyword: Optional[str] = None) -> bool:
        """
        Close an explicit target window.
        Examples: close this window, close window, close chrome, close youtube
        """
        # Foreground window
        if (
            not target_keyword
            or target_keyword in {"this", "current", "active", "this window"}
            or RE_ACTIVE_WINDOW.search(target_keyword)
        ):
            hwnd = user32.GetForegroundWindow()
            if hwnd and user32.IsWindow(hwnd):
                user32.PostMessageW(hwnd, WM_CLOSE, 0, 0)
                return True
            return False

        # Explicit title
        return self._close_window_by_title(target_keyword)

    def _close_window_by_title(self, title_keyword: str) -> bool:
        """Send WM_CLOSE to every matching visible top-level window."""
        target = title_keyword.lower().strip()
        if not target:
            return False

        closed_any = False

        def enum_handler(hwnd, _):
            nonlocal closed_any
            if user32.IsWindowVisible(hwnd):
                title = self._get_window_text(hwnd)
                if title and target in title.lower():
                    user32.PostMessageW(hwnd, WM_CLOSE, 0, 0)
                    closed_any = True
            return True

        user32.EnumWindows(WNDENUMPROC(enum_handler), 0)
        return closed_any

    def _close_process(self, proc_name: str) -> bool:
        """
        Force-close a process only when needed.
        Returns True when taskkill was successfully started.
        """
        if not proc_name:
            return False

        try:
            result = subprocess.run(
                ["taskkill", "/F", "/IM", proc_name],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                check=False,
            )
            return result.returncode == 0
        except Exception as exc:
            logger.debug("Failed to close process %s: %s", proc_name, exc)
            return False

    # ==========================================================================
    # Keyboard & System Hotkeys
    # ==========================================================================

    @staticmethod
    def _send_hotkey(*keys: int):
        for key in keys:
            user32.keybd_event(key, 0, 0, 0)
        for key in reversed(keys):
            user32.keybd_event(key, 0, KEYEVENTF_KEYUP, 0)

    def _show_desktop(self):
        self._send_hotkey(VK_LWIN, VK_D)

    def _minimize_all(self):
        self._send_hotkey(VK_LWIN, VK_M)

    def _restore_all(self):
        self._send_hotkey(VK_LWIN, VK_SHIFT, VK_M)

    # ==========================================================================
    # System Paths
    # ==========================================================================

    @staticmethod
    def _open_system_path(path: str):
        try:
            os.startfile(path)
        except Exception as exc:
            logger.error("Failed to open system path %s: %s", path, exc)
            raise

    # ==========================================================================
    # Generic Application Launcher
    # ==========================================================================

    def _launch_app_by_command(self, app_name: str) -> None:
        """Launch an application through Windows Start."""
        try:
            subprocess.Popen(
                ["cmd", "/c", "start", "", app_name],
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
        except Exception as exc:
            logger.error("Failed to launch %s: %s", app_name, exc)
            raise

    # ==========================================================================
    # Alias Application to Text
    # ==========================================================================

    def _apply_aliases(self, text: str) -> str:
        """Apply spoken aliases to text."""
        normalized = text
        for alias, canonical in sorted(
            self.aliases.items(),
            key=lambda item: len(item[0]),
            reverse=True,
        ):
            normalized = re.sub(
                rf"\b{re.escape(alias)}\b",
                canonical,
                normalized,
                flags=re.IGNORECASE,
            )
        return normalized

    # ==========================================================================
    # OPEN COMMAND
    # ==========================================================================

    def _handle_open(self, text_clean: str) -> Tuple[bool, str]:
        """
        Handle all OPEN/LAUNCH/START/RUN requests.
        UNKNOWN targets are deliberately consumed here so they never reach Tier 3.
        """
        if not RE_OPEN_TRIGGER.search(text_clean):
            return False, ""

        normalized_text = self._apply_aliases(text_clean)
        target = self._extract_target(normalized_text, RE_OPEN_TRIGGER)

        # ------------------------------------------------------
        # No target
        # ------------------------------------------------------
        if not target:
            return True, "Please specify the app or website you want me to open."

        # ------------------------------------------------------
        # Known local application
        # ------------------------------------------------------
        for pattern, launch_fn, display_name, _, _ in self._compiled_local_apps:
            if pattern.search(normalized_text):
                try:
                    launch_fn()
                    return True, f"Opening {display_name}."
                except Exception as exc:
                    logger.error("Failed opening %s: %s", display_name, exc)
                    return True, f"Failed to open {display_name}."

        # ------------------------------------------------------
        # Known website
        # ------------------------------------------------------
        for pattern, url, display_name, _ in self._compiled_sites:
            if pattern.search(normalized_text):
                try:
                    self._open_url(url)
                    return True, f"Opening {display_name}."
                except Exception as exc:
                    logger.error("Failed opening %s: %s", display_name, exc)
                    return True, f"Failed to open {display_name}."

        # ------------------------------------------------------
        # UNKNOWN OPEN TARGET
        # ------------------------------------------------------
        return True, f"I couldn't find the app or website '{target}'."

    # ==========================================================================
    # CLOSE COMMAND
    # ==========================================================================

    def _handle_close(self, text_clean: str) -> Tuple[bool, str]:
        """
        Handle all CLOSE/KILL/EXIT/QUIT requests.
        Unknown targets are consumed here so that Tier 3 cannot interpret them.
        """
        if not RE_CLOSE_TRIGGER.search(text_clean):
            return False, ""

        normalized_text = self._apply_aliases(text_clean)
        target = self._extract_target(normalized_text, RE_CLOSE_TRIGGER)

        # ------------------------------------------------------
        # "close window" / "close this window"
        # ------------------------------------------------------
        if target in {None, "", "this", "current", "active", "this window"}:
            ok = self._close_window()
            if ok:
                return True, "Closed the current window."
            return True, "I couldn't close the current window."

        # ------------------------------------------------------
        # Known local application
        # ------------------------------------------------------
        for pattern, _, display_name, process_name, window_title in self._compiled_local_apps:
            if pattern.search(normalized_text):
                window_closed = self._close_window(window_title)
                process_closed = False

                if not window_closed:
                    process_closed = self._close_process(process_name)

                if window_closed or process_closed:
                    return True, f"Closing {display_name}."

                return True, f"I couldn't find {display_name}."

        # ------------------------------------------------------
        # Known website / PWA
        # ------------------------------------------------------
        for pattern, _, display_name, window_title in self._compiled_sites:
            if pattern.search(normalized_text):
                if self._close_window(window_title):
                    return True, f"Closing {display_name}."
                return True, f"I couldn't find {display_name}."

        # ------------------------------------------------------
        # UNKNOWN CLOSE TARGET
        # ------------------------------------------------------
        if self._close_window(target):
            return True, f"Closing {target}."

        return True, f"I couldn't find the app or website '{target}'."

    # ==========================================================================
    # MAIN EXECUTION
    # ==========================================================================

    def execute(self, text: str) -> Tuple[bool, str]:
        text_clean = self._normalize_text(text)
        if not text_clean:
            return False, ""

        # ============================================================
        # 1. INSTANT STOP / SILENCE
        # ============================================================
        if text_clean in STOP_COMMANDS:
            if self.tts:
                try:
                    self.tts.stop()
                except Exception:
                    logger.exception("Failed to stop TTS.")
            return True, "Stopped."

        # ============================================================
        # 2. SMART WINDOW MANAGEMENT
        # ============================================================
        is_volume_command = bool(re.search(r"\bvolume\b|\bsound\b", text_clean))
        if not is_volume_command:
            # Minimize all
            if RE_MIN_ALL_TRIGGER.search(text_clean):
                self._minimize_all()
                return True, "Minimized all windows."

            # Show desktop
            if RE_SHOW_DESKTOP_TRIGGER.search(text_clean):
                self._show_desktop()
                return True, "Showing the desktop."

            # Restore all
            if RE_RESTORE_ALL_TRIGGER.search(text_clean):
                self._restore_all()
                return True, "Restored all windows."

            # Maximize / Minimize / Restore
            for trigger, action, phrase in (
                (RE_MAXIMIZE_TRIGGER, SW_MAXIMIZE, "Maximized"),
                (RE_MINIMIZE_TRIGGER, SW_MINIMIZE, "Minimized"),
                (RE_RESTORE_TRIGGER, SW_RESTORE, "Restored"),
            ):
                if trigger.search(text_clean):
                    target = self._extract_target(text_clean, trigger)
                    target = self._resolve_window_target(target)
                    ok = self._window_action(action, target)
                    if ok:
                        return True, f"{phrase} {target}." if target else f"{phrase} this window."
                    return True, "I couldn't find that window."

        # ============================================================
        # 3. COMMON WINDOWS UTILITIES
        # ============================================================
        if RE_LOCK_TRIGGER.search(text_clean):
            user32.LockWorkStation()
            return True, "Windows is locked."

        if RE_TASK_MANAGER_TRIGGER.search(text_clean):
            try:
                subprocess.Popen(["taskmgr.exe"])
                return True, "Opening Task Manager."
            except Exception as exc:
                logger.error("Failed opening Task Manager: %s", exc)
                return True, "Failed to open Task Manager."

        if RE_DEVICE_MANAGER_TRIGGER.search(text_clean):
            try:
                subprocess.Popen(["mmc.exe", "devmgmt.msc"])
                return True, "Opening Device Manager."
            except Exception as exc:
                logger.error("Failed opening Device Manager: %s", exc)
                return True, "Failed to open Device Manager."

        if RE_CONTROL_PANEL_TRIGGER.search(text_clean):
            try:
                subprocess.Popen(["control.exe"])
                return True, "Opening Control Panel."
            except Exception as exc:
                logger.error("Failed opening Control Panel: %s", exc)
                return True, "Failed to open Control Panel."

        if RE_SETTINGS_TRIGGER.search(text_clean):
            try:
                os.startfile("ms-settings:")
                return True, "Opening Settings."
            except Exception as exc:
                logger.error("Failed opening Settings: %s", exc)
                return True, "Failed to open Settings."

        if RE_DOWNLOADS_TRIGGER.search(text_clean):
            downloads_path = os.path.join(os.path.expanduser("~"), "Downloads")
            try:
                self._open_system_path(downloads_path)
                return True, "Opening Downloads."
            except Exception:
                return True, "I couldn't open Downloads."

        if RE_DOCUMENTS_TRIGGER.search(text_clean):
            documents_path = os.path.join(os.path.expanduser("~"), "Documents")
            try:
                self._open_system_path(documents_path)
                return True, "Opening Documents."
            except Exception:
                return True, "I couldn't open Documents."

        # ============================================================
        # 4. OPEN
        # ============================================================
        if RE_OPEN_TRIGGER.search(text_clean):
            return self._handle_open(text_clean)

        # ============================================================
        # 5. CLOSE
        # ============================================================
        if RE_CLOSE_TRIGGER.search(text_clean):
            return self._handle_close(text_clean)

        # ============================================================
        # 6. NOT HANDLED
        # ============================================================
        return False, ""