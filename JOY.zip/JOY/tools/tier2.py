# ==============================================================================
# Imports
# ==============================================================================

import ctypes
from ctypes import wintypes
from datetime import datetime
import logging
import os
import re
import shutil
import subprocess
import time
from typing import Optional, Tuple
from urllib.parse import quote_plus
import webbrowser

import psutil

# Optional screenshot dependency (Pillow is required for screenshot commands)
try:
    from PIL import ImageGrab
except ImportError:
    ImageGrab = None

# Local / Application Imports
from ai.llm import LocalLLM


# ==============================================================================
# Global Configuration & Win32 Setup
# ==============================================================================

logger = logging.getLogger(__name__)

kernel32 = ctypes.windll.kernel32
user32 = ctypes.windll.user32


# ==============================================================================
# Win32 Constants
# ==============================================================================

SM_XVIRTUALSCREEN = 76
SM_YVIRTUALSCREEN = 77
SM_CXVIRTUALSCREEN = 78
SM_CYVIRTUALSCREEN = 79


# ==============================================================================
# Win32 Structures
# ==============================================================================

class SYSTEM_POWER_STATUS(ctypes.Structure):
    _fields_ = [
        ("ACLineStatus", wintypes.BYTE),
        ("BatteryFlag", wintypes.BYTE),
        ("BatteryLifePercent", wintypes.BYTE),
        ("SystemStatusFlag", wintypes.BYTE),
        ("BatteryLifeTime", wintypes.DWORD),
        ("BatteryFullLifeTime", wintypes.DWORD),
    ]


class RECT(ctypes.Structure):
    _fields_ = [
        ("left", wintypes.LONG),
        ("top", wintypes.LONG),
        ("right", wintypes.LONG),
        ("bottom", wintypes.LONG),
    ]


# ==============================================================================
# Deterministic Command Regular Expressions
# ==============================================================================

# ------------------------------------------------------------------------------
# Volume
# ------------------------------------------------------------------------------

RE_SET_VOLUME = re.compile(
    r"\b(?:set|change|put|turn)\s+"
    r"(?:the\s+)?volume\s*(?:to|at)?\s*"
    r"(\d{1,3})\s*%?\b",
    re.IGNORECASE,
)

RE_VOLUME_VALUE = re.compile(
    r"\bvolume\s*(?:to|at)?\s*"
    r"(\d{1,3})\s*%?\b",
    re.IGNORECASE,
)

RE_VOLUME_INCREASE_BY = re.compile(
    r"\b(?:increase|raise|turn\s+up|boost)\s+"
    r"(?:the\s+)?volume\s*(?:by\s*)?"
    r"(\d{1,3})\s*%?\b",
    re.IGNORECASE,
)

RE_VOLUME_DECREASE_BY = re.compile(
    r"\b(?:decrease|lower|reduce|turn\s+down)\s+"
    r"(?:the\s+)?volume\s*(?:by\s*)?"
    r"(\d{1,3})\s*%?\b",
    re.IGNORECASE,
)

RE_VOLUME_UP = re.compile(
    r"\b(?:increase|raise|turn\s+up)\s+"
    r"(?:the\s+)?volume\b",
    re.IGNORECASE,
)

RE_VOLUME_DOWN = re.compile(
    r"\b(?:decrease|lower|reduce|turn\s+down)\s+"
    r"(?:the\s+)?volume\b",
    re.IGNORECASE,
)

RE_VOLUME_MAX = re.compile(
    r"\b(?:maximize|max(?:imum)?|full)\s+"
    r"(?:the\s+)?volume\b"
    r"|\bvolume\s+(?:to\s+)?max(?:imum)?\b",
    re.IGNORECASE,
)

RE_VOLUME_MIN = re.compile(
    r"\b(?:minimize|min(?:imum)?|mute)\s+"
    r"(?:the\s+)?volume\b"
    r"|\bvolume\s+(?:to\s+)?min(?:imum)?\b",
    re.IGNORECASE,
)

RE_MUTE = re.compile(
    r"\b(?:mute|silence)\s+"
    r"(?:the\s+)?(?:system\s+)?"
    r"(?:audio|sound|volume)\b"
    r"|\bmute\s*$",
    re.IGNORECASE,
)

RE_UNMUTE = re.compile(
    r"\b(?:unmute|unsilence|"
    r"turn\s+(?:the\s+)?(?:sound|audio)\s+back\s+on)\b",
    re.IGNORECASE,
)

# ------------------------------------------------------------------------------
# Web / Search
# ------------------------------------------------------------------------------

RE_YOUTUBE_SEARCH = re.compile(
    r"\b(?:search|play|find)\s+"
    r"(?:on\s+)?youtube\s+"
    r"(?:(?:for|about|search)\s+)?(.+)$",
    re.IGNORECASE,
)

RE_SEARCH_YOUTUBE = re.compile(
    r"\b(?:search|find)\s+"
    r"(?:for\s+)?(.+?)\s+"
    r"(?:on|in)\s+youtube\b",
    re.IGNORECASE,
)

RE_PLAY_YOUTUBE = re.compile(
    r"\bplay\s+(.+?)\s+"
    r"(?:on|in)\s+youtube\b",
    re.IGNORECASE,
)

RE_GOOGLE_SEARCH = re.compile(
    r"^(?:search\s+(?:google\s+)?|google\s+search\s+)"
    r"(.+)$",
    re.IGNORECASE,
)

RE_SEARCH_GENERAL = re.compile(
    r"^(?:search|find)\s+"
    r"(?:for\s+)?(.+)$",
    re.IGNORECASE,
)

# ------------------------------------------------------------------------------
# Battery
# ------------------------------------------------------------------------------

RE_BATTERY_PERCENT = re.compile(
    r"\b(?:what(?:'s| is)|tell me|show me|check|get|"
    r"how much)\s+(?:my\s+)?"
    r"(?:battery|charge|battery charge)"
    r"(?:\s+(?:percentage|percent|level))?\b"
    r"|\bwhat percentage is my battery\b"
    r"|\bbattery percentage\b",
    re.IGNORECASE,
)

RE_BATTERY_TIME = re.compile(
    r"\b(?:how long|how much time)\s+"
    r"(?:will|can)\s+"
    r"(?:my\s+)?battery\s+last\b"
    r"|\b(?:battery|charge)\s+"
    r"(?:time|remaining time|time left)\b"
    r"|\bhow much battery time is left\b",
    re.IGNORECASE,
)

RE_BATTERY_CHARGING = re.compile(
    r"\b(?:am i charging|"
    r"is (?:my\s+)?(?:battery|laptop|computer) charging|"
    r"is (?:my\s+)?battery charging|"
    r"am i connected to power|"
    r"is my charger connected)\b",
    re.IGNORECASE,
)

RE_BATTERY_GENERAL = re.compile(
    r"\b(?:battery|charge|power status|battery level|"
    r"battery status)\b",
    re.IGNORECASE,
)

# ------------------------------------------------------------------------------
# CPU / RAM / GPU / System Usage
# ------------------------------------------------------------------------------

RE_RAM_USAGE = re.compile(
    r"\b(?:how much|what)\s+"
    r"(?:ram|memory)"
    r"(?:\s+(?:am i using|is being used|usage|used))?\b"
    r"|\b(?:ram|memory)\s+usage\b",
    re.IGNORECASE,
)

RE_CPU_USAGE = re.compile(
    r"\b(?:what is|what's|how much is|show me|tell me|"
    r"check|what)\s+"
    r"(?:my\s+)?cpu\s+(?:usage|utilization)\b"
    r"|\bcpu\s+usage\b"
    r"|\bcpu\s+utilization\b",
    re.IGNORECASE,
)

RE_GPU_USAGE = re.compile(
    r"\b(?:what is|what's|how much is|show me|tell me|"
    r"check|what)\s+"
    r"(?:my\s+)?gpu\s+(?:usage|utilization)\b"
    r"|\bgpu\s+usage\b"
    r"|\bgpu\s+utilization\b",
    re.IGNORECASE,
)

RE_SYSTEM_USAGE = re.compile(
    r"^(?:tell me|show me|give me|check|tell|what is|what's)?"
    r"\s*(?:my\s+)?system\s+(?:usage|status)\b"
    r"|\bhow is my system doing\b"
    r"|\b(?:cpu|ram|memory|gpu|disk|battery)\s+"
    r"(?:status|usage)\s+overview\b",
    re.IGNORECASE,
)

# ------------------------------------------------------------------------------
# Screenshot
# ------------------------------------------------------------------------------

RE_SCREENSHOT_FULL = re.compile(
    r"\b(?:take|capture|make|get)"
    r"\s+(?:a\s+)?"
    r"(?:screenshot|screen\s*shot|"
    r"screen\s*capture|screen\s*clip)"
    r"\b",
    re.IGNORECASE,
)

RE_SCREENSHOT_WINDOW = re.compile(
    r"\b(?:capture|take|screenshot)"
    r"\s+(?:this|the current|current|active)\s+window\b"
    r"|\bcapture this window\b"
    r"|\btake a screenshot of this window\b",
    re.IGNORECASE,
)

RE_SCREENSHOT_TARGET = re.compile(
    r"\b(?:take|capture)\s+"
    r"(?:a\s+)?screenshot\s+of\s+(.+)$",
    re.IGNORECASE,
)

# ------------------------------------------------------------------------------
# Network / Diagnostics
# ------------------------------------------------------------------------------

RE_WIFI_STATUS = re.compile(
    r"\b(?:check|show|tell me|what(?:'s| is)|get|see|is|are)\s+"
    r"(?:my\s+)?wi[ -]?fi"
    r"(?:\s+(?:status|state|connection|connected|working|online))?\b"
    r"|\bwi[ -]?fi\s+(?:status|state|connection|connected|"
    r"working|online)\b"
    r"|\bis\s+(?:my\s+)?wi[ -]?fi\s+connected\b",
    re.IGNORECASE,
)

RE_INTERNET_STATUS = re.compile(
    r"\b(?:check|test|show|tell me|what(?:'s| is)|get|see|is|am)\s+"
    r"(?:my\s+)?internet"
    r"(?:\s+(?:connection|status|working|online|available))?\b"
    r"|\binternet\s+(?:connection|status|connection status|"
    r"working|online|available)\b"
    r"|\bam i online\b",
    re.IGNORECASE,
)

RE_DISK_SPACE = re.compile(
    r"\b(?:check|show|tell me|what(?:'s| is)|get|see|"
    r"how much|how many)\s+"
    r"(?:my\s+)?(?:disk|disc|drive|storage)"
    r"(?:\s+(?:space|usage|free|free space|available|"
    r"available space|storage))?\b"
    r"|\b(?:disk|disc|drive|storage)\s+"
    r"(?:space|usage|free space|available space)\b"
    r"|\bhow much\s+(?:disk|disc|drive|storage)\s+space"
    r"\s+(?:is\s+)?free\b"
    r"|\bhow much\s+(?:free\s+)?"
    r"(?:disk|disc|drive|storage)\s+space\s+"
    r"(?:do i have|is left|is available)\b",
    re.IGNORECASE,
)

RE_UPTIME = re.compile(
    r"\b(?:check|show|tell me|what(?:'s| is)|get|see)\s+"
    r"(?:my\s+)?(?:system|pc|computer|machine)\s+uptime\b"
    r"|\bhow long\s+(?:has\s+(?:the\s+)?)?(?:my\s+)?"
    r"(?:pc|computer|system|machine)\s+been\s+running\b"
    r"|\bhow long\s+(?:has\s+)?(?:my\s+)?"
    r"(?:pc|computer|system|machine)\s+(?:has\s+)?"
    r"been\s+running\b",
    re.IGNORECASE,
)


# ==============================================================================
# Tier 2 Handler
# ==============================================================================

class Tier2Handler:
    """
    Fast deterministic OS/system intent layer.
    Tier 2 never calls the LLM.

    Supported:
        - Volume
        - Mute/unmute
        - YouTube/Google search
        - Battery percentage
        - Battery remaining time
        - Charging state
        - CPU usage
        - RAM usage
        - GPU usage
        - Combined system usage
        - Screenshots
        - Wi-Fi status
        - Internet status
        - Disk space
        - Uptime
    """

    def __init__(self, llm: LocalLLM):
        self.llm = llm

        # GPU result cache.
        # Avoids repeatedly querying Windows performance
        # counters when multiple commands arrive quickly.
        self._gpu_cache_value: Optional[float] = None
        self._gpu_cache_time = 0.0
        self._gpu_cache_ttl = 1.0

    # ==========================================================================
    # AUDIO
    # ==========================================================================

    def _audio_endpoint(self):
        import pythoncom
        from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume
        from comtypes import CLSCTX_ALL

        pythoncom.CoInitialize()
        try:
            devices = AudioUtilities.GetSpeakers()
            interface = devices.Activate(
                IAudioEndpointVolume._iid_,
                CLSCTX_ALL,
                None,
            )
            endpoint = interface.QueryInterface(IAudioEndpointVolume)
            return endpoint, pythoncom
        except Exception:
            pythoncom.CoUninitialize()
            raise

    def _get_volume(self) -> int:
        try:
            volume, pythoncom = self._audio_endpoint()
            try:
                return round(volume.GetMasterVolumeLevelScalar() * 100)
            finally:
                pythoncom.CoUninitialize()
        except Exception as exc:
            logger.error("Volume read error: %s", exc)
            return 50

    def _set_volume(self, level: int) -> str:
        level = max(0, min(100, int(level)))
        try:
            volume, pythoncom = self._audio_endpoint()
            try:
                volume.SetMasterVolumeLevelScalar(level / 100.0, None)
            finally:
                pythoncom.CoUninitialize()
            return f"Volume set to {level} percent."
        except Exception as exc:
            logger.error("Volume adjustment error: %s", exc)
            return "Failed to set volume."

    def _change_volume(self, delta: int) -> str:
        return self._set_volume(self._get_volume() + delta)

    def _get_mute_state(self):
        volume, pythoncom = self._audio_endpoint()
        try:
            return bool(volume.GetMute())
        finally:
            pythoncom.CoUninitialize()

    def _set_mute(self, muted: bool) -> str:
        try:
            volume, pythoncom = self._audio_endpoint()
            try:
                volume.SetMute(1 if muted else 0, None)
            finally:
                pythoncom.CoUninitialize()
            return "System audio muted." if muted else "System audio unmuted."
        except Exception as exc:
            logger.error("Mute control error: %s", exc)
            return "Failed to change mute state."

    # ==========================================================================
    # BATTERY
    # ==========================================================================

    def _read_power_status(self) -> Optional[SYSTEM_POWER_STATUS]:
        try:
            status = SYSTEM_POWER_STATUS()
            success = kernel32.GetSystemPowerStatus(ctypes.byref(status))
            if not success:
                return None
            return status
        except Exception as exc:
            logger.error("Battery status error: %s", exc)
            return None

    @staticmethod
    def _format_seconds(seconds: int) -> str:
        if seconds < 0:
            return ""

        hours, remainder = divmod(int(seconds), 3600)
        minutes, _ = divmod(remainder, 60)

        if hours > 0:
            return (
                f"{hours} hour{'s' if hours != 1 else ''} "
                f"and {minutes} minute{'s' if minutes != 1 else ''}"
            )
        return f"{minutes} minute{'s' if minutes != 1 else ''}"

    def _get_battery_percent(self) -> str:
        status = self._read_power_status()
        if status is None:
            return "Unable to read battery percentage."

        percent = int(status.BatteryLifePercent)
        if percent == 255:
            return "Unable to determine the battery percentage."
        return f"Battery is at {percent} percent."

    def _get_battery_time(self) -> str:
        status = self._read_power_status()
        if status is None:
            return "Unable to read remaining battery time."

        percent = int(status.BatteryLifePercent)
        if percent == 255:
            percent = None

        seconds = int(status.BatteryLifeTime)

        # Windows documents this as -1/unknown when
        # remaining time cannot be determined or AC is connected.
        if (
            seconds == 0xFFFFFFFF
            or status.ACLineStatus == 1
            or status.BatteryFlag & 8
        ):
            if status.ACLineStatus == 1:
                return "The charger is connected, so remaining battery time is not applicable."
            return "Windows cannot currently estimate the remaining battery time."

        formatted = self._format_seconds(seconds)
        if not formatted:
            return "Windows cannot currently estimate the remaining battery time."

        if percent is not None:
            return f"About {formatted} of battery life remains at {percent} percent."
        return f"About {formatted} of battery life remains."

    def _get_battery_charging(self) -> str:
        status = self._read_power_status()
        if status is None:
            return "Unable to determine charging status."

        percent = int(status.BatteryLifePercent)
        charging = bool(status.BatteryFlag & 8)
        ac_connected = (status.ACLineStatus == 1)

        if charging:
            if percent != 255 and percent >= 100:
                return "The charger is connected and the battery is full."
            return "Yes, the charger is connected and the battery is charging."

        if ac_connected:
            return "The charger is connected, but the battery is not currently charging."

        return "No, the computer is running on battery power."

    def _get_battery_status(self) -> str:
        status = self._read_power_status()
        if status is None:
            return "Unable to read battery status."

        percent = int(status.BatteryLifePercent)
        charging = bool(status.BatteryFlag & 8)
        ac_connected = (status.ACLineStatus == 1)

        if percent == 255:
            percent_text = "battery percentage is unavailable"
        else:
            percent_text = f"battery is at {percent} percent"

        if charging:
            power_text = "and charging"
        elif ac_connected:
            power_text = "and connected to AC power"
        else:
            power_text = "and running on battery power"

        return f"The {percent_text} {power_text}."

    # ==========================================================================
    # CPU / RAM
    # ==========================================================================

    def _get_cpu_usage_value(self) -> float:
        try:
            # Very short sample keeps Tier 2 responsive
            # while avoiding the first-call 0.0 problem.
            return float(psutil.cpu_percent(interval=0.05))
        except Exception as exc:
            logger.error("CPU usage error: %s", exc)
            return -1.0

    def _get_cpu_usage(self) -> str:
        usage = self._get_cpu_usage_value()
        if usage < 0:
            return "Unable to read CPU usage."
        return f"CPU usage is {usage:.0f} percent."

    def _get_ram_usage_data(self) -> Tuple[float, float, float, float]:
        memory = psutil.virtual_memory()
        used_gb = memory.used / (1024 ** 3)
        total_gb = memory.total / (1024 ** 3)
        available_gb = memory.available / (1024 ** 3)
        percent = float(memory.percent)
        return used_gb, total_gb, available_gb, percent

    def _get_ram_usage(self) -> str:
        try:
            used_gb, total_gb, _, percent = self._get_ram_usage_data()
            return (
                f"RAM usage is {percent:.0f} percent. "
                f"{used_gb:.1f} GB of {total_gb:.1f} GB is in use."
            )
        except Exception as exc:
            logger.error("RAM usage error: %s", exc)
            return "Unable to read RAM usage."

    # ==========================================================================
    # GPU
    # ==========================================================================

    def _get_gpu_usage_value(self) -> Optional[float]:
        """
        Read Windows GPU Engine utilization.

        Windows exposes GPU Engine counters through the performance-counter
        subsystem. We query the active engines and use the highest utilization
        value as the overall GPU activity estimate.
        """
        now = time.monotonic()
        if self._gpu_cache_value is not None and (now - self._gpu_cache_time) < self._gpu_cache_ttl:
            return self._gpu_cache_value

        powershell_script = r"""
$values = @(
    Get-Counter '\GPU Engine(*)\Utilization Percentage' -ErrorAction Stop |
    Select-Object -ExpandProperty CounterSamples |
    ForEach-Object { [double]$_.CookedValue }
)

if ($values.Count -eq 0) {
    exit 2
}

($values | Measure-Object -Maximum).Maximum
"""
        try:
            result = subprocess.run(
                [
                    "powershell.exe",
                    "-NoProfile",
                    "-NonInteractive",
                    "-ExecutionPolicy",
                    "Bypass",
                    "-Command",
                    powershell_script,
                ],
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="ignore",
                timeout=2.0,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                check=False,
            )

            if result.returncode != 0:
                return None

            value_text = result.stdout.strip()
            if not value_text:
                return None

            value = float(value_text.splitlines()[-1])
            # Clamp to expected percentage range
            value = max(0.0, min(100.0, value))

            self._gpu_cache_value = value
            self._gpu_cache_time = now
            return value

        except (subprocess.TimeoutExpired, ValueError, OSError) as exc:
            logger.debug("GPU usage query failed: %s", exc)
            return None
        except Exception as exc:
            logger.error("GPU usage error: %s", exc)
            return None

    def _get_gpu_usage(self) -> str:
        usage = self._get_gpu_usage_value()
        if usage is None:
            return "Unable to read GPU usage from the Windows GPU performance counters."
        return f"GPU usage is {usage:.0f} percent."

    # ==========================================================================
    # DISK
    # ==========================================================================

    def _get_disk_data(self) -> Tuple[float, float, float]:
        root = os.environ.get("SystemDrive", "C:") + "\\"
        total, used, free = shutil.disk_usage(root)
        total_gb = total / (1024 ** 3)
        used_gb = used / (1024 ** 3)
        free_gb = free / (1024 ** 3)
        return total_gb, used_gb, free_gb

    def _get_disk_space(self) -> str:
        try:
            total_gb, used_gb, free_gb = self._get_disk_data()
            used_percent = (used_gb / total_gb * 100) if total_gb else 0
            return (
                f"Drive C has {free_gb:.1f} GB free out of {total_gb:.1f} GB, "
                f"with {used_percent:.0f} percent used."
            )
        except Exception as exc:
            logger.error("Disk space error: %s", exc)
            return "Unable to read disk space."

    # ==========================================================================
    # SYSTEM USAGE
    # ==========================================================================

    def _get_system_usage(self) -> str:
        """
        Return the complete overview: CPU, RAM, GPU, Disk, Battery.
        """
        # CPU
        cpu = self._get_cpu_usage_value()
        cpu_text = "unavailable" if cpu < 0 else f"{cpu:.0f} percent"

        # RAM
        try:
            ram_used, ram_total, _, ram_percent = self._get_ram_usage_data()
            ram_text = f"{ram_percent:.0f} percent ({ram_used:.1f} of {ram_total:.1f} GB)"
        except Exception:
            ram_text = "unavailable"

        # GPU
        gpu = self._get_gpu_usage_value()
        gpu_text = "unavailable" if gpu is None else f"{gpu:.0f} percent"

        # Disk
        try:
            disk_total, disk_used, disk_free = self._get_disk_data()
            disk_percent = (disk_used / disk_total * 100) if disk_total else 0
            disk_text = f"{disk_percent:.0f} percent used ({disk_free:.1f} GB free)"
        except Exception:
            disk_text = "unavailable"

        # Battery
        status = self._read_power_status()
        if status is None:
            battery_text = "unavailable"
        else:
            percent = int(status.BatteryLifePercent)
            battery_text = "percentage unavailable" if percent == 255 else f"{percent} percent"

            charging = bool(status.BatteryFlag & 8)
            ac_connected = (status.ACLineStatus == 1)

            if charging:
                battery_text += ", charging"
            elif ac_connected:
                battery_text += ", connected to AC power"
            else:
                seconds = int(status.BatteryLifeTime)
                if seconds != 0xFFFFFFFF and seconds > 0:
                    remaining = self._format_seconds(seconds)
                    if remaining:
                        battery_text += f", about {remaining} remaining"
                else:
                    battery_text += ", on battery"

        return (
            f"CPU {cpu_text}. "
            f"RAM {ram_text}. "
            f"GPU {gpu_text}. "
            f"Disk {disk_text}. "
            f"Battery {battery_text}."
        )

    # ==========================================================================
    # SCREENSHOT HELPERS
    # ==========================================================================

    @staticmethod
    def _screenshot_directory() -> str:
        pictures = os.path.join(os.path.expanduser("~"), "Pictures")
        directory = os.path.join(pictures, "JOY Screenshots")
        os.makedirs(directory, exist_ok=True)
        return directory

    @staticmethod
    def _timestamped_filename(prefix: str) -> str:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        return f"{prefix}_{timestamp}.png"

    def _take_full_screenshot(self) -> str:
        if ImageGrab is None:
            return "Screenshot support is unavailable. Install Pillow."

        try:
            image = ImageGrab.grab(all_screens=True)
            directory = self._screenshot_directory()
            filename = self._timestamped_filename("screenshot")
            path = os.path.join(directory, filename)
            image.save(path, "PNG")
            return f"Screenshot saved to {path}."
        except Exception as exc:
            logger.error("Full screenshot error: %s", exc, exc_info=True)
            return "Failed to capture the screen."

    def _get_window_title(self, hwnd: int) -> str:
        length = user32.GetWindowTextLengthW(hwnd)
        if length <= 0:
            return ""

        buffer = ctypes.create_unicode_buffer(length + 1)
        user32.GetWindowTextW(hwnd, buffer, length + 1)
        return buffer.value

    def _get_window_rect(self, hwnd: int) -> Optional[Tuple[int, int, int, int]]:
        rect = RECT()
        if not user32.GetWindowRect(hwnd, ctypes.byref(rect)):
            return None
        return int(rect.left), int(rect.top), int(rect.right), int(rect.bottom)

    def _find_window_by_keyword(self, keyword: str) -> Optional[int]:
        keyword = keyword.lower().strip()
        if not keyword:
            return None

        found: list[int] = []
        callback_type = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

        @callback_type
        def enum_handler(hwnd, _):
            if not user32.IsWindowVisible(hwnd):
                return True

            title = self._get_window_title(hwnd)
            if title and keyword in title.lower():
                found.append(hwnd)
                return False
            return True

        user32.EnumWindows(enum_handler, 0)
        return found[0] if found else None

    def _take_window_screenshot(self, hwnd: int, label: str) -> str:
        if ImageGrab is None:
            return "Screenshot support is unavailable. Install Pillow."

        if not hwnd or not user32.IsWindow(hwnd):
            return f"I couldn't find the {label} window."

        rect = self._get_window_rect(hwnd)
        if rect is None:
            return f"I couldn't get the {label} window bounds."

        left, top, right, bottom = rect
        if right <= left or bottom <= top:
            return f"The {label} window is not capturable right now."

        try:
            image = ImageGrab.grab(
                bbox=(left, top, right, bottom),
                all_screens=True,
            )
            directory = self._screenshot_directory()
            filename = self._timestamped_filename(label.replace(" ", "_"))
            path = os.path.join(directory, filename)
            image.save(path, "PNG")
            return f"{label.capitalize()} screenshot saved to {path}."
        except Exception as exc:
            logger.error("Window screenshot error: %s", exc, exc_info=True)
            return f"Failed to capture the {label} window."

    def _take_active_window_screenshot(self) -> str:
        hwnd = user32.GetForegroundWindow()
        if not hwnd:
            return "I couldn't find the active window."
        return self._take_window_screenshot(hwnd, "active window")

    def _take_target_screenshot(self, target: str) -> str:
        target = target.strip().lower()

        # Specific browser checks
        if "chrome" in target:
            hwnd = self._find_window_by_keyword("chrome")
            if hwnd:
                return self._take_window_screenshot(hwnd, "Chrome")
            return "I couldn't find a Chrome window."

        if "edge" in target:
            hwnd = self._find_window_by_keyword("edge")
            if hwnd:
                return self._take_window_screenshot(hwnd, "Edge")
            return "I couldn't find an Edge window."

        # Literal window title lookup
        hwnd = self._find_window_by_keyword(target)
        if hwnd:
            return self._take_window_screenshot(hwnd, target)
        return f"I couldn't find a window for '{target}'."

    # ==========================================================================
    # WIFI
    # ==========================================================================

    def _get_wifi_status(self) -> str:
        try:
            result = subprocess.run(
                ["netsh", "wlan", "show", "interfaces"],
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="ignore",
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                timeout=2.0,
                check=False,
            )

            output = result.stdout
            state = re.search(r"^\s*State\s*:\s*(.+)$", output, re.MULTILINE | re.IGNORECASE)
            ssid = re.search(r"^\s*SSID\s*:\s*(.+)$", output, re.MULTILINE | re.IGNORECASE)
            signal = re.search(r"^\s*Signal\s*:\s*(.+)$", output, re.MULTILINE | re.IGNORECASE)

            if state and state.group(1).strip().lower() == "connected":
                name = ssid.group(1).strip() if ssid else "unknown network"
                strength = signal.group(1).strip() if signal else "unknown"
                return f"Wi-Fi is connected to {name} with {strength} percent signal."

            return "Wi-Fi is not connected."

        except Exception as exc:
            logger.error("Wi-Fi status error: %s", exc)
            return "Unable to read Wi-Fi status."

    # ==========================================================================
    # INTERNET
    # ==========================================================================

    def _get_internet_status(self) -> str:
        import urllib.request

        try:
            request = urllib.request.Request(
                "https://www.msftconnecttest.com/connecttest.txt",
                method="GET",
            )
            with urllib.request.urlopen(request, timeout=1.5) as response:
                if 200 <= response.status < 400:
                    return "Internet connection is working."
            return "Internet connection is unavailable."
        except Exception:
            return "Internet connection is unavailable."

    # ==========================================================================
    # UPTIME
    # ==========================================================================

    def _get_uptime(self) -> str:
        try:
            seconds = max(0, time.time() - psutil.boot_time())
            days, remainder = divmod(int(seconds), 86400)
            hours, remainder = divmod(remainder, 3600)
            minutes, _ = divmod(remainder, 60)

            parts = []
            if days:
                parts.append(f"{days} day{'s' if days != 1 else ''}")
            if hours:
                parts.append(f"{hours} hour{'s' if hours != 1 else ''}")
            if minutes or not parts:
                parts.append(f"{minutes} minute{'s' if minutes != 1 else ''}")

            return "System uptime is " + ", ".join(parts) + "."
        except Exception as exc:
            logger.error("Uptime error: %s", exc)
            return "Unable to read system uptime."

    # ==========================================================================
    # SEARCH
    # ==========================================================================

    @staticmethod
    def _open_google_search(query: str) -> Tuple[bool, str]:
        query = query.strip()
        if not query:
            return True, "Please tell me what you want me to search for."

        url = "https://www.google.com/search?q=" + quote_plus(query)
        webbrowser.open(url)
        return True, f"Searching Google for {query}."

    @staticmethod
    def _open_youtube_search(query: str) -> Tuple[bool, str]:
        query = query.strip()
        if not query:
            return True, "Please tell me what you want me to search for on YouTube."

        url = "https://www.youtube.com/results?search_query=" + quote_plus(query)
        webbrowser.open(url)
        return True, f"Searching YouTube for {query}."

    # ==========================================================================
    # MAIN EXECUTION
    # ==========================================================================

    def execute(self, text: str) -> Tuple[bool, str]:
        # Normalize only whitespace/case here to avoid expensive transformations
        text_clean = re.sub(r"\s+", " ", text.strip())
        if not text_clean:
            return False, ""

        text_lower = text_clean.lower()

        # ======================================================
        # 1. MUTE / UNMUTE
        # ======================================================
        if RE_UNMUTE.search(text_lower):
            return True, self._set_mute(False)

        if RE_MUTE.search(text_lower) and "volume" not in text_lower:
            return True, self._set_mute(True)

        # ======================================================
        # 2. VOLUME
        # ======================================================
        match = RE_SET_VOLUME.search(text_lower) or RE_VOLUME_VALUE.search(text_lower)
        if match:
            return True, self._set_volume(int(match.group(1)))

        if RE_VOLUME_MAX.search(text_lower):
            return True, self._set_volume(100)

        if RE_VOLUME_MIN.search(text_lower):
            return True, self._set_volume(0)

        match = RE_VOLUME_INCREASE_BY.search(text_lower)
        if match:
            return True, self._change_volume(int(match.group(1)))

        match = RE_VOLUME_DECREASE_BY.search(text_lower)
        if match:
            return True, self._change_volume(-int(match.group(1)))

        if RE_VOLUME_UP.search(text_lower):
            return True, self._change_volume(10)

        if RE_VOLUME_DOWN.search(text_lower):
            return True, self._change_volume(-10)

        # ======================================================
        # 3. SYSTEM USAGE (Checked before individual metrics)
        # ======================================================
        if RE_SYSTEM_USAGE.fullmatch(text_lower):
            return True, self._get_system_usage()

        # ======================================================
        # 4. CPU ONLY
        # ======================================================
        if RE_CPU_USAGE.search(text_lower):
            return True, self._get_cpu_usage()

        # ======================================================
        # 5. RAM ONLY
        # ======================================================
        if RE_RAM_USAGE.search(text_lower):
            return True, self._get_ram_usage()

        # ======================================================
        # 6. GPU ONLY
        # ======================================================
        if RE_GPU_USAGE.search(text_lower):
            return True, self._get_gpu_usage()

        # ======================================================
        # 7. BATTERY (Specific intents first)
        # ======================================================
        if RE_BATTERY_PERCENT.search(text_lower):
            return True, self._get_battery_percent()

        if RE_BATTERY_TIME.search(text_lower):
            return True, self._get_battery_time()

        if RE_BATTERY_CHARGING.search(text_lower):
            return True, self._get_battery_charging()

        if RE_BATTERY_GENERAL.search(text_lower):
            return True, self._get_battery_status()

        # ======================================================
        # 8. SCREENSHOT (Target/window before full screen)
        # ======================================================
        if RE_SCREENSHOT_WINDOW.search(text_lower):
            return True, self._take_active_window_screenshot()

        target_match = RE_SCREENSHOT_TARGET.search(text_clean)
        if target_match:
            target = target_match.group(1).strip()
            return True, self._take_target_screenshot(target)

        if RE_SCREENSHOT_FULL.search(text_lower):
            return True, self._take_full_screenshot()

        # ======================================================
        # 9. YOUTUBE SEARCH
        # ======================================================
        match = RE_SEARCH_YOUTUBE.search(text_clean)
        if match:
            return self._open_youtube_search(match.group(1))

        match = RE_PLAY_YOUTUBE.search(text_clean)
        if match:
            return self._open_youtube_search(match.group(1))

        match = RE_YOUTUBE_SEARCH.search(text_clean)
        if match:
            return self._open_youtube_search(match.group(1))

        # ======================================================
        # 10. GOOGLE SEARCH
        # ======================================================
        match = RE_GOOGLE_SEARCH.search(text_clean)
        if match:
            return self._open_google_search(match.group(1))

        # Generic search only when clearly introduced as "search" / "find"
        match = RE_SEARCH_GENERAL.search(text_clean)
        if match:
            return self._open_google_search(match.group(1))

        # ======================================================
        # 11. WIFI
        # ======================================================
        if RE_WIFI_STATUS.search(text_lower):
            return True, self._get_wifi_status()

        # ======================================================
        # 12. INTERNET
        # ======================================================
        if RE_INTERNET_STATUS.search(text_lower):
            return True, self._get_internet_status()

        # ======================================================
        # 13. DISK
        # ======================================================
        if RE_DISK_SPACE.search(text_lower):
            return True, self._get_disk_space()

        # ======================================================
        # 14. UPTIME
        # ======================================================
        if RE_UPTIME.search(text_lower):
            return True, self._get_uptime()

        # ======================================================
        # NOT HANDLED
        # ======================================================
        return False, ""