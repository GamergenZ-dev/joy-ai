import ctypes
from ctypes import wintypes
from datetime import date, datetime
import logging
import subprocess
from typing import Dict, Generator, Optional, Tuple

import psutil

from ai.llm import LocalLLM

logger = logging.getLogger(__name__)

# ============================================================
# WIN32 APIS & TELEMETRY STRUCTURES
# ============================================================
kernel32 = ctypes.windll.kernel32

class SYSTEM_POWER_STATUS(ctypes.Structure):
    """Win32 Native Battery Status Structure (<0.1ms)."""
    _fields_ = [
        ("ACLineStatus", wintypes.BYTE),
        ("BatteryFlag", wintypes.BYTE),
        ("BatteryLifePercent", wintypes.BYTE),
        ("SystemStatusFlag", wintypes.BYTE),
        ("BatteryLifeTime", wintypes.DWORD),
        ("BatteryFullLifeTime", wintypes.DWORD),
    ]

# Static Calendar Registry: (Event Name, Month, Day)
KNOWN_EVENTS: Dict[str, Tuple[str, int, int]] = {
    "indian independence": ("Indian Independence Day", 8, 15),
    "independence day": ("Independence Day", 8, 15),
    "republic day": ("Indian Republic Day", 1, 26),
    "gandhi jayanti": ("Gandhi Jayanti", 10, 2),
    "christmas": ("Christmas", 12, 25),
    "new year": ("New Year", 1, 1),
    "halloween": ("Halloween", 10, 31),
}

# Pre-defined keyword tuples for rapid O(1) in-memory checks
CALENDAR_KEYWORDS = ("how many days", "days left", "days until", "countdown", "when is")
BATTERY_PRIMARY_KEYWORDS = ("battery", "charge", "plug in", "power left")
BATTERY_CONTEXT_KEYWORDS = ("should i", "can i", "enough", "last", "how long", "movie", "game", "drain")
SYSTEM_KEYWORDS = ("cpu", "ram", "memory usage", "computer running", "system performance", "lagging", "overload")
CLIPBOARD_KEYWORDS = ("clipboard", "what did i copy", "copied text", "read what i copied")


# ============================================================
# TIER 4: TOOL-AUGMENTED CONVERSATIONAL REASONING
# ============================================================
class Tier4Handler:
    """
    Tier 4: Tool-Augmented Conversational Reasoning.
    Gathers live system telemetry and deterministic data (battery, hardware,
    clipboard, calendar math) and streams contextual responses via the LLM.
    """

    def __init__(self, llm: LocalLLM):
        self.llm = llm

    # ============================================================
    # 1. LIVE TELEMETRY COLLECTORS
    # ============================================================

    def _get_battery_data(self) -> str:
        """Fetches raw battery percentage and charging state."""
        try:
            status = SYSTEM_POWER_STATUS()
            if kernel32.GetSystemPowerStatus(ctypes.byref(status)):
                percent = status.BatteryLifePercent
                if percent != 255:
                    charging = "plugged in and charging" if status.ACLineStatus == 1 else "running on battery"
                    return f"Battery Level: {percent}%, Power State: {charging}."
            return "Battery Status: Desktop PC running on AC power."
        except Exception as e:
            return f"Battery status unavailable: {e}"

    def _get_system_performance(self) -> str:
        """Fetches CPU load and RAM metrics."""
        try:
            cpu_usage = psutil.cpu_percent(interval=0.1)
            memory = psutil.virtual_memory()
            used_gb = round(memory.used / (1024**3), 1)
            total_gb = round(memory.total / (1024**3), 1)
            return f"CPU Load: {cpu_usage}%, RAM Usage: {memory.percent}% ({used_gb} GB used of {total_gb} GB)."
        except Exception:
            return "System performance metrics could not be fetched."

    def _get_clipboard_data(self) -> str:
        """Reads text from Windows clipboard."""
        try:
            cmd = "powershell -NoProfile -Command Get-Clipboard"
            result = subprocess.check_output(cmd, shell=True, timeout=1.0).decode("utf-8", errors="ignore").strip()
            if result:
                trimmed = result[:300] + "..." if len(result) > 300 else result
                return f"Clipboard text: '{trimmed}'"
            return "Clipboard is currently empty."
        except Exception:
            return "Unable to access clipboard."

    def _get_calendar_countdown(self, text: str) -> Optional[str]:
        """Calculates exact date deltas to eliminate LLM arithmetic hallucinations."""
        today = datetime.now().date()
        text_lower = text.lower()

        for key, (event_name, month, day) in KNOWN_EVENTS.items():
            if key in text_lower:
                target_year = today.year
                target_date = date(target_year, month, day)

                # Roll over to next year if the event has already passed this year
                if target_date < today:
                    target_year += 1
                    target_date = date(target_year, month, day)

                delta_days = (target_date - today).days

                if delta_days == 0:
                    return f"Live Calendar Context: Today ({today.strftime('%B %d, %Y')}) is {event_name}!"
                elif delta_days == 1:
                    return (
                        f"Live Calendar Context: Today is {today.strftime('%B %d, %Y')}. "
                        f"{event_name} is tomorrow on {target_date.strftime('%B %d, %Y')} (exactly 1 day left)."
                    )
                else:
                    return (
                        f"Live Calendar Context: Today is {today.strftime('%B %d, %Y')}. "
                        f"{event_name} is on {target_date.strftime('%B %d, %Y')} (exactly {delta_days} days left)."
                    )

        return None

    # ============================================================
    # 2. TIER 4 INTENT DETECTION
    # ============================================================

    def check_and_gather_context(self, text: str) -> Optional[Tuple[str, str]]:
        """
        Determines if the query requires tool inspection + conversational reasoning.
        Returns: (tool_name, live_telemetry_context) or None.
        """
        text_lower = text.lower()

        # 1. Holiday and Event Countdowns
        if any(w in text_lower for w in CALENDAR_KEYWORDS):
            calendar_context = self._get_calendar_countdown(text)
            if calendar_context:
                return "calendar_countdown", calendar_context

        # 2. Complex Battery / Power Queries
        if any(w in text_lower for w in BATTERY_PRIMARY_KEYWORDS) and any(
            w in text_lower for w in BATTERY_CONTEXT_KEYWORDS
        ):
            return "battery_reasoning", self._get_battery_data()

        # 3. System Hardware Performance Queries
        if any(w in text_lower for w in SYSTEM_KEYWORDS):
            return "system_performance", self._get_system_performance()

        # 4. Clipboard Queries
        if any(w in text_lower for w in CLIPBOARD_KEYWORDS):
            return "clipboard_inspection", self._get_clipboard_data()

        return None

    # ============================================================
    # 3. CONTEXT-AUGMENTED STREAM GENERATOR
    # ============================================================

    def execute_stream(self, text: str, tool_context: str) -> Generator[str, None, None]:
        """
        Routes through the dedicated tool reasoning streamer to preserve
        unified conversational memory and live ground-truth telemetry.
        """
        if hasattr(self.llm, "generate_tool_reasoning_stream"):
            return self.llm.generate_tool_reasoning_stream(text, tool_context)

        # Fallback if method is missing in LocalLLM
        prompt = (
            f"[LIVE SYSTEM TELEMETRY]: {tool_context}\n\n"
            f"User Question: {text}\n"
            f"Answer the user directly and concisely in 1 or 2 spoken sentences using the telemetry provided above."
        )
        return self.llm.generate_speech_response_stream(prompt)