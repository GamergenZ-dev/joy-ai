import logging
import os
import sys
from pathlib import Path
from typing import Optional, Tuple

import numpy as np
import torch


logger = logging.getLogger(__name__)


# ============================================================
# 3D-SPEAKER PATH
# ============================================================

CURRENT_DIR = Path(__file__).resolve().parent
PROJECT_DIR = CURRENT_DIR.parent

THREE_D_SPEAKER_DIR = (
    PROJECT_DIR / "3D-Speaker"
)

if not THREE_D_SPEAKER_DIR.exists():
    raise FileNotFoundError(
        "3D-Speaker directory was not found.\n"
        f"Expected:\n{THREE_D_SPEAKER_DIR}\n\n"
        "Place the official 3D-Speaker repository there."
    )

sys.path.insert(
    0,
    str(THREE_D_SPEAKER_DIR),
)


# ============================================================
# OFFICIAL 3D-SPEAKER IMPORTS
# ============================================================

from speakerlab.process.processor import FBank
from speakerlab.utils.builder import dynamic_import

from modelscope.hub.snapshot_download import (
    snapshot_download,
)


# ============================================================
# MODEL CONFIG
# ============================================================

MODEL_ID = (
    "iic/speech_eres2netv2_sv_zh-cn_16k-common"
)

MODEL_REVISION = "v1.0.1"

MODEL_CLASS = (
    "speakerlab.models.eres2net.ERes2NetV2.ERes2NetV2"
)

MODEL_CHECKPOINT = (
    "pretrained_eres2netv2.ckpt"
)

MODEL_ARGS = {
    "feat_dim": 80,
    "embedding_size": 192,
}


# ============================================================
# SPEAKER VERIFIER
# ============================================================

class SpeakerVerifier:
    """
    Local speaker verification using the official
    3D-Speaker ERes2NetV2 model.

    Pipeline:

        Raw audio
            ↓
        Audio preparation
            ↓
        Speech-only VAD trimming
            ↓
        80-dim FBank
            ↓
        ERes2NetV2
            ↓
        192-dim embedding
            ↓
        Cosine similarity

    Public API intentionally remains compatible with JOY:

        verifier.enrolled

        verifier.verify(audio)
            -> (accepted, score)

        verifier.create_profile(samples)
            -> bool
    """

    def __init__(
        self,
        sample_rate: int = 16000,
        model_source: str = MODEL_ID,
        model_dir: Optional[str] = None,
        profile_path: Optional[str] = None,
        threshold: float = 0.50,
    ):
        self.sample_rate = int(
            sample_rate
        )

        if self.sample_rate != 16000:
            raise ValueError(
                "ERes2NetV2 is configured for 16 kHz audio."
            )

        self.model_source = model_source

        self.threshold = float(
            threshold
        )

        # --------------------------------------------------------
        # Paths
        # --------------------------------------------------------

        if model_dir is None:
            model_dir = (
                CURRENT_DIR
                / "models"
                / "eres2netv2"
            )

        if profile_path is None:
            profile_path = (
                CURRENT_DIR
                / "speaker_profile.npy"
            )

        self.model_dir = Path(
            model_dir
        )

        self.profile_path = Path(
            profile_path
        )

        self.model_dir.mkdir(
            parents=True,
            exist_ok=True,
        )

        # --------------------------------------------------------
        # Model
        # --------------------------------------------------------

        logger.info(
            "Loading official 3D-Speaker ERes2NetV2..."
        )

        self.embedding_model = (
            self._load_model()
        )

        self.embedding_model.eval()

        self.device = torch.device(
            "cpu"
        )

        self.embedding_model.to(
            self.device
        )

        # --------------------------------------------------------
        # Official feature extractor
        # --------------------------------------------------------

        self.feature_extractor = FBank(
            80,
            sample_rate=16000,
            mean_nor=True,
        )

        # --------------------------------------------------------
        # Reference profile
        # --------------------------------------------------------

        self.reference_embedding: Optional[
            torch.Tensor
        ] = None

        self.load_profile()

        logger.info(
            "JOY ERes2NetV2 speaker verifier initialized."
        )

    # ============================================================
    # MODEL LOADING
    # ============================================================

    def _load_model(self):
        """
        Download/load the official ERes2NetV2 checkpoint
        and instantiate the model.
        """

        logger.info(
            "Downloading/checking ERes2NetV2 model..."
        )

        cache_dir = snapshot_download(
            self.model_source,
            revision=MODEL_REVISION,
        )

        cache_dir = Path(
            cache_dir
        )

        checkpoint = (
            cache_dir
            / MODEL_CHECKPOINT
        )

        if not checkpoint.exists():
            raise FileNotFoundError(
                "ERes2NetV2 checkpoint was not found:\n"
                f"{checkpoint}"
            )

        logger.info(
            "Loading checkpoint: %s",
            checkpoint,
        )

        model_class = dynamic_import(
            MODEL_CLASS
        )

        model = model_class(
            **MODEL_ARGS
        )

        state = torch.load(
            checkpoint,
            map_location="cpu",
        )

        # --------------------------------------------------------
        # Handle wrapped state dictionaries.
        # --------------------------------------------------------

        if isinstance(
            state,
            dict
        ):

            if "state_dict" in state:
                state = state[
                    "state_dict"
                ]

            elif "model" in state:
                state = state[
                    "model"
                ]

        # --------------------------------------------------------
        # Remove DDP prefix.
        # --------------------------------------------------------

        if isinstance(
            state,
            dict
        ):

            cleaned_state = {}

            for key, value in state.items():

                if key.startswith(
                    "module."
                ):
                    key = key[
                        len("module.") :
                    ]

                cleaned_state[
                    key
                ] = value

            state = cleaned_state

        model.load_state_dict(
            state,
            strict=True,
        )

        model.eval()

        logger.info(
            "ERes2NetV2 model loaded successfully."
        )

        return model

    # ============================================================
    # ENROLLED
    # ============================================================

    @property
    def enrolled(self) -> bool:
        return (
            self.reference_embedding
            is not None
        )

    # ============================================================
    # PROFILE
    # ============================================================

    def load_profile(self) -> bool:
        """
        Load the saved 192-dimensional speaker embedding.
        """

        if not self.profile_path.exists():

            logger.warning(
                "No ERes2NetV2 speaker profile found: %s",
                self.profile_path,
            )

            self.reference_embedding = None

            return False

        try:

            embedding = np.load(
                self.profile_path
            )

            embedding = np.asarray(
                embedding,
                dtype=np.float32,
            )

            if embedding.ndim == 1:

                embedding = (
                    embedding.reshape(
                        1,
                        -1,
                    )
                )

            if embedding.size == 0:

                raise ValueError(
                    "Speaker profile is empty."
                )

            if embedding.shape[-1] != 192:

                raise ValueError(
                    "Invalid ERes2NetV2 embedding size: "
                    f"{embedding.shape[-1]}; expected 192."
                )

            tensor = torch.from_numpy(
                embedding
            )

            tensor = (
                self._normalize_embedding(
                    tensor
                )
            )

            self.reference_embedding = (
                tensor
            )

            logger.info(
                "Speaker profile loaded successfully."
            )

            return True

        except Exception as exc:

            logger.error(
                "Failed to load speaker profile: %s",
                exc,
                exc_info=True,
            )

            self.reference_embedding = None

            return False

    # ============================================================
    # AUDIO PREPARATION
    # ============================================================

    @staticmethod
    def _prepare_audio(
        audio: np.ndarray,
    ) -> np.ndarray:
        """
        Convert audio to mono contiguous float32.
        """

        if audio is None:

            return np.zeros(
                0,
                dtype=np.float32,
            )

        audio = np.asarray(
            audio,
            dtype=np.float32,
        )

        if audio.ndim > 1:

            audio = np.mean(
                audio,
                axis=1,
            )

        audio = np.nan_to_num(
            audio,
            nan=0.0,
            posinf=0.0,
            neginf=0.0,
        )

        return np.ascontiguousarray(
            audio,
            dtype=np.float32,
        )

    # ============================================================
    # SPEECH-ONLY VAD
    # ============================================================

    def _trim_to_speech(
        self,
        audio: np.ndarray,
    ) -> np.ndarray:
        """
        Lightweight energy-based speech trimming.

        Removes:
            - leading silence
            - trailing silence
            - very quiet noise-only regions

        Keeps:
            - natural pauses inside speech
            - a small amount of context around speech

        This is intentionally implemented with NumPy only
        so the speaker verifier stays lightweight and fast.
        """

        if audio is None or len(audio) == 0:
            return np.zeros(
                0,
                dtype=np.float32,
            )

        audio = self._prepare_audio(
            audio
        )

        duration = (
            len(audio)
            / self.sample_rate
        )

        # Do not attempt aggressive trimming on
        # extremely short audio.
        if duration < 0.30:
            return audio

        # --------------------------------------------------------
        # Frame configuration
        # --------------------------------------------------------

        frame_ms = 20

        frame_size = max(
            1,
            int(
                self.sample_rate
                * frame_ms
                / 1000
            ),
        )

        frame_count = (
            len(audio)
            // frame_size
        )

        if frame_count < 5:
            return audio

        usable_length = (
            frame_count
            * frame_size
        )

        framed = audio[
            :usable_length
        ].reshape(
            frame_count,
            frame_size,
        )

        # --------------------------------------------------------
        # RMS per frame
        # --------------------------------------------------------

        frame_rms = np.sqrt(
            np.mean(
                framed * framed,
                axis=1,
            )
        )

        if not np.any(
            np.isfinite(frame_rms)
        ):

            return audio

        frame_rms = np.nan_to_num(
            frame_rms,
            nan=0.0,
            posinf=0.0,
            neginf=0.0,
        )

        # --------------------------------------------------------
        # Noise estimation
        #
        # Lower-energy frames are assumed to represent
        # background/silence more often than speech.
        # --------------------------------------------------------

        noise_floor = float(
            np.percentile(
                frame_rms,
                20,
            )
        )

        median_energy = float(
            np.median(
                frame_rms
            )
        )

        high_energy = float(
            np.percentile(
                frame_rms,
                80,
            )
        )

        # Robust energy threshold.
        #
        # Absolute floor prevents an almost silent recording
        # from being treated as speech.
        absolute_floor = 0.006

        adaptive_threshold = max(
            absolute_floor,
            noise_floor * 2.5,
            median_energy * 0.45,
        )

        # If the recording has almost no energy variation,
        # trimming would be unreliable.
        if (
            high_energy
            <= max(
                noise_floor * 1.35,
                absolute_floor,
            )
        ):

            return audio

        # --------------------------------------------------------
        # Speech frame mask
        # --------------------------------------------------------

        speech_mask = (
            frame_rms
            >= adaptive_threshold
        )

        # --------------------------------------------------------
        # Remove isolated one-frame spikes.
        #
        # A single loud click/fan spike should not become
        # the complete speaker segment.
        # --------------------------------------------------------

        if len(
            speech_mask
        ) >= 3:

            isolated = (
                speech_mask[1:-1]
                & ~speech_mask[:-2]
                & ~speech_mask[2:]
            )

            speech_mask[1:-1][
                isolated
            ] = False

        if not np.any(
            speech_mask
        ):

            return audio

        # --------------------------------------------------------
        # Find first/last speech frame.
        # --------------------------------------------------------

        speech_indices = np.flatnonzero(
            speech_mask
        )

        first_frame = int(
            speech_indices[0]
        )

        last_frame = int(
            speech_indices[-1]
        )

        # --------------------------------------------------------
        # Context padding.
        #
        # 100 ms before/after preserves consonant beginnings
        # and phrase endings.
        # --------------------------------------------------------

        padding_frames = max(
            1,
            int(
                0.10
                * self.sample_rate
                / frame_size
            ),
        )

        first_frame = max(
            0,
            first_frame
            - padding_frames,
        )

        last_frame = min(
            frame_count - 1,
            last_frame
            + padding_frames,
        )

        start_sample = (
            first_frame
            * frame_size
        )

        end_sample = min(
            len(audio),
            (
                last_frame + 1
            )
            * frame_size,
        )

        trimmed = audio[
            start_sample:end_sample
        ]

        # --------------------------------------------------------
        # Safety check.
        # --------------------------------------------------------

        trimmed_duration = (
            len(trimmed)
            / self.sample_rate
        )

        if trimmed_duration < 0.50:

            return audio

        # Prevent pathological output sizes.
        max_seconds = 10.0

        max_samples = int(
            max_seconds
            * self.sample_rate
        )

        if len(trimmed) > max_samples:

            trimmed = trimmed[
                :max_samples
            ]

        logger.debug(
            "Speech trim: %.2fs -> %.2fs",
            duration,
            len(trimmed)
            / self.sample_rate,
        )

        return np.ascontiguousarray(
            trimmed,
            dtype=np.float32,
        )

    # ============================================================
    # EMBEDDING NORMALIZATION
    # ============================================================

    @staticmethod
    def _normalize_embedding(
        embedding: torch.Tensor,
    ) -> torch.Tensor:
        """
        L2-normalize speaker embeddings.
        """

        embedding = (
            embedding.float()
        )

        norm = torch.linalg.norm(
            embedding,
            dim=-1,
            keepdim=True,
        ).clamp_min(
            1e-8
        )

        return (
            embedding / norm
        )

    # ============================================================
    # EXTRACT FEATURES
    # ============================================================

    def _extract_features(
        self,
        audio: np.ndarray,
    ) -> Optional[torch.Tensor]:
        """
        Convert speech-only waveform into the official
        80-dimensional FBank representation.
        """

        audio = (
            self._prepare_audio(
                audio
            )
        )

        if len(audio) == 0:
            return None

        # 3D-Speaker FBank expects a torch.Tensor.
        wav = torch.from_numpy(
            audio
        ).float()

        try:

            features = (
                self.feature_extractor(
                    wav
                )
            )

            if not isinstance(
                features,
                torch.Tensor,
            ):

                features = torch.as_tensor(
                    features,
                    dtype=torch.float32,
                )

            features = (
                features.float()
            )

            if features.ndim != 2:

                raise RuntimeError(
                    "Unexpected FBank shape: "
                    f"{tuple(features.shape)}"
                )

            if features.shape[-1] != 80:

                raise RuntimeError(
                    "Unexpected FBank feature dimension: "
                    f"{features.shape[-1]}"
                )

            return features

        except Exception as exc:

            logger.error(
                "FBank extraction failed: %s",
                exc,
                exc_info=True,
            )

            return None

    # ============================================================
    # EMBEDDING
    # ============================================================

    def get_embedding(
        self,
        audio: np.ndarray,
    ) -> Optional[torch.Tensor]:
        """
        Generate one 192-dimensional speaker embedding.

        Audio is first reduced to the speech-only region
        before feature extraction.
        """

        audio = (
            self._prepare_audio(
                audio
            )
        )

        duration = (
            len(audio)
            / self.sample_rate
        )

        if duration < 0.80:

            logger.debug(
                "Speaker audio too short: %.2fs",
                duration,
            )

            return None

        # --------------------------------------------------------
        # Speech-only trimming
        # --------------------------------------------------------

        trimmed_audio = (
            self._trim_to_speech(
                audio
            )
        )

        if (
            trimmed_audio is None
            or len(trimmed_audio) == 0
        ):

            return None

        trimmed_duration = (
            len(trimmed_audio)
            / self.sample_rate
        )

        if trimmed_duration < 0.80:

            logger.debug(
                "Speech-only audio too short: %.2fs",
                trimmed_duration,
            )

            return None

        # --------------------------------------------------------
        # Maximum input duration
        # --------------------------------------------------------

        max_seconds = 10.0

        max_samples = int(
            max_seconds
            * self.sample_rate
        )

        if len(trimmed_audio) > max_samples:

            trimmed_audio = (
                trimmed_audio[
                    :max_samples
                ]
            )

        # --------------------------------------------------------
        # FBank
        # --------------------------------------------------------

        features = (
            self._extract_features(
                trimmed_audio
            )
        )

        if features is None:
            return None

        # --------------------------------------------------------
        # Model input [B, T, F]
        # --------------------------------------------------------

        features = (
            features.unsqueeze(
                0
            )
        )

        features = (
            features.to(
                self.device
            )
        )

        try:

            with torch.inference_mode():

                embedding = (
                    self.embedding_model(
                        features
                    )
                )

            if not isinstance(
                embedding,
                torch.Tensor,
            ):

                embedding = torch.as_tensor(
                    embedding
                )

            embedding = (
                embedding.float()
            )

            # Expected [1, 192].
            if embedding.ndim == 1:

                embedding = (
                    embedding.unsqueeze(
                        0
                    )
                )

            if embedding.shape[-1] != 192:

                raise RuntimeError(
                    "Unexpected ERes2NetV2 embedding shape: "
                    f"{tuple(embedding.shape)}"
                )

            embedding = (
                self._normalize_embedding(
                    embedding
                )
            )

            return embedding.cpu()

        except Exception as exc:

            logger.error(
                "ERes2NetV2 embedding extraction failed: %s",
                exc,
                exc_info=True,
            )

            return None

    # ============================================================
    # COSINE SIMILARITY
    # ============================================================

    def similarity(
        self,
        audio: np.ndarray,
    ) -> Optional[float]:
        """
        Calculate cosine similarity against
        the enrolled speaker profile.
        """

        if not self.enrolled:
            return None

        reference = (
            self.reference_embedding
        )

        if reference is None:
            return None

        embedding = (
            self.get_embedding(
                audio
            )
        )

        if embedding is None:
            return None

        reference = (
            self._normalize_embedding(
                reference
            )
        )

        embedding = (
            self._normalize_embedding(
                embedding
            )
        )

        with torch.inference_mode():

            score = torch.sum(
                embedding
                * reference,
                dim=-1,
            )

        return float(
            score.squeeze().item()
        )

    # ============================================================
    # VERIFY
    # ============================================================

    def verify(
        self,
        audio: np.ndarray,
    ) -> Tuple[bool, Optional[float]]:
        """
        Verify whether an audio sample belongs
        to the enrolled speaker.

        Returns:
            (accepted, cosine_similarity)
        """

        if not self.enrolled:

            logger.warning(
                "Cannot verify speaker: "
                "no profile is enrolled."
            )

            return False, None

        score = (
            self.similarity(
                audio
            )
        )

        if score is None:

            return False, None

        accepted = (
            score >= self.threshold
        )

        logger.info(
            "ERes2NetV2 speaker verification: "
            "score=%.4f threshold=%.4f accepted=%s",
            score,
            self.threshold,
            accepted,
        )

        return accepted, score

    # ============================================================
    # PROFILE CREATION
    # ============================================================

    def create_profile(
        self,
        audio_samples: list[np.ndarray],
    ) -> bool:
        """
        Create an enrolled speaker profile from
        multiple speech recordings.

        Each recording goes through the same speech-only
        trimming pipeline used during verification.
        """

        if not audio_samples:

            logger.error(
                "No enrollment samples supplied."
            )

            return False

        embeddings = []

        total = len(
            audio_samples
        )

        for index, audio in enumerate(
            audio_samples,
            start=1,
        ):

            logger.info(
                "Processing enrollment sample %d/%d...",
                index,
                total,
            )

            embedding = (
                self.get_embedding(
                    audio
                )
            )

            if embedding is None:

                logger.warning(
                    "Enrollment sample %d "
                    "could not produce an embedding.",
                    index,
                )

                continue

            embeddings.append(
                embedding
            )

        if not embeddings:

            logger.error(
                "No valid enrollment embeddings."
            )

            return False

        # --------------------------------------------------------
        # Average embeddings
        # --------------------------------------------------------

        stacked = torch.cat(
            embeddings,
            dim=0,
        )

        profile = torch.mean(
            stacked,
            dim=0,
            keepdim=True,
        )

        profile = (
            self._normalize_embedding(
                profile
            )
        )

        profile_numpy = (
            profile.cpu()
            .numpy()
            .astype(np.float32)
        )

        # --------------------------------------------------------
        # Save
        # --------------------------------------------------------

        self.profile_path.parent.mkdir(
            parents=True,
            exist_ok=True,
        )

        np.save(
            self.profile_path,
            profile_numpy,
        )

        self.reference_embedding = (
            profile.cpu()
        )

        logger.info(
            "ERes2NetV2 speaker profile saved: %s",
            self.profile_path,
        )

        logger.info(
            "Valid enrollment samples: %d/%d",
            len(embeddings),
            total,
        )

        return True

    # ============================================================
    # REMOVE PROFILE
    # ============================================================

    def remove_profile(self) -> bool:
        """
        Delete the enrolled speaker profile.
        """

        self.reference_embedding = None

        if not self.profile_path.exists():
            return True

        try:

            self.profile_path.unlink()

            logger.info(
                "Speaker profile removed."
            )

            return True

        except OSError as exc:

            logger.error(
                "Failed to remove speaker profile: %s",
                exc,
            )

            return False