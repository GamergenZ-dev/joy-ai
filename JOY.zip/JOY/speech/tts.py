import logging
import queue
import re
import sys
import threading
from pathlib import Path
from typing import Generator, List

sys.path.append(str(Path(__file__).resolve().parent.parent))

import config

logger = logging.getLogger(__name__)

# ============================================================
# SAPI5 CONSTANTS & SENTINELS
# ============================================================

SVSF_DEFAULT = 0
SVS_FLAGS_ASYNC = 1
SVSF_PURGE_BEFORE_SPEAK = 2

SENTINEL_SYNC = "__SAPI_SYNC_FLUSH__"
SENTINEL_SHUTDOWN = "__SAPI_SHUTDOWN__"


class StreamingTTS:
    """
    Persistent Windows SAPI5 streaming TTS engine.

    All TTS tuning lives in config.TTS_CONFIG.
    No performance/audio tuning constants are embedded here.

    Public API preserved:
        stream_llm_response()
        speak()
        stop()
        shutdown()
    """

    def __init__(self):
        # ========================================================
        # CONFIGURATION
        # ========================================================

        cfg = config.TTS_CONFIG

        self.rate = cfg["rate"]
        self.volume = cfg["volume"]
        self.voice_index = cfg["voice_index"]

        self.queue_maxsize = cfg["queue_maxsize"]
        self.worker_timeout = cfg["worker_timeout"]
        self.first_chunk_words = cfg["first_chunk_words"]
        self.first_sentence_min_words = cfg["first_sentence_min_words"]
        self.next_chunk_words = cfg["next_chunk_words"]
        self.next_sentence_min_words = cfg["next_sentence_min_words"]
        self.soft_boundary_enabled = cfg["soft_boundary_enabled"]
        self.soft_boundary_min_words = cfg["soft_boundary_min_words"]

        self.sapi_rate_offset = cfg["sapi_rate_offset"]
        self.sapi_rate_scale = cfg["sapi_rate_scale"]
        self.sapi_rate_min = cfg["sapi_rate_min"]
        self.sapi_rate_max = cfg["sapi_rate_max"]

        self.sapi_volume_min = cfg["sapi_volume_min"]
        self.sapi_volume_max = cfg["sapi_volume_max"]

        self.shutdown_join_timeout = cfg["shutdown_join_timeout"]

        # ========================================================
        # STATE
        # ========================================================

        self.speech_queue: queue.Queue = queue.Queue(
            maxsize=self.queue_maxsize
        )

        self.is_running = True

        self._is_speaking = False
        self._state_lock = threading.Lock()

        self._sapi_speaker = None
        self._pyttsx_engine = None
        self._com_initialized = False

        # ========================================================
        # WORKER
        # ========================================================

        self.worker_thread = threading.Thread(
            target=self._worker,
            daemon=True,
            name="JOY-TTS-Worker",
        )
        self.worker_thread.start()

    # ============================================================
    # STATE
    # ============================================================

    @property
    def is_speaking(self) -> bool:
        with self._state_lock:
            return self._is_speaking

    def _set_speaking(self, value: bool) -> None:
        with self._state_lock:
            self._is_speaking = value

    # ============================================================
    # SAPI5 INITIALIZATION
    # ============================================================

    def _init_native_engine(self):
        """
        Initialize the SAPI COM object inside the worker thread.
        """

        try:
            import pythoncom

            pythoncom.CoInitialize()
            self._com_initialized = True

        except ImportError:
            logger.debug(
                "pythoncom unavailable; continuing."
            )

        except Exception as exc:
            logger.debug(
                f"COM initialization warning: {exc}"
            )

        # --------------------------------------------------------
        # Native SAPI5
        # --------------------------------------------------------

        try:
            import win32com.client

            speaker = win32com.client.Dispatch(
                "SAPI.SpVoice"
            )

            # Config-driven WPM -> SAPI rate mapping.
            sapi_rate = int(
                (float(self.rate) - self.sapi_rate_offset)
                / self.sapi_rate_scale
            ) + 1

            sapi_rate = max(
                self.sapi_rate_min,
                min(
                    self.sapi_rate_max,
                    sapi_rate,
                ),
            )

            speaker.Rate = sapi_rate

            speaker.Volume = max(
                self.sapi_volume_min,
                min(
                    self.sapi_volume_max,
                    int(float(self.volume) * 100),
                ),
            )

            voices = speaker.GetVoices()

            if (
                voices is not None
                and 0 <= int(self.voice_index) < voices.Count
            ):
                speaker.Voice = voices.Item(
                    int(self.voice_index)
                )

            self._sapi_speaker = speaker

            logger.info(
                "Initialized Native Windows SAPI5 Async Streaming Engine."
            )
            return

        except Exception as exc:
            logger.debug(
                f"Direct SAPI5 initialization bypassed: {exc}"
            )

        # --------------------------------------------------------
        # pyttsx3 fallback
        # --------------------------------------------------------

        try:
            import pyttsx3

            engine = pyttsx3.init()

            engine.setProperty(
                "rate",
                self.rate,
            )

            engine.setProperty(
                "volume",
                self.volume,
            )

            voices = engine.getProperty(
                "voices"
            )

            if (
                voices
                and 0 <= int(self.voice_index) < len(voices)
            ):
                engine.setProperty(
                    "voice",
                    voices[int(self.voice_index)].id,
                )

            self._pyttsx_engine = engine

            logger.info(
                "Initialized pyttsx3 fallback."
            )

        except Exception as exc:
            logger.error(
                f"Failed to initialize TTS engine: {exc}"
            )

    # ============================================================
    # SAPI HELPERS
    # ============================================================

    def _sapi_speak_async(
        self,
        text: str,
    ) -> None:
        if not self._sapi_speaker:
            return

        self._sapi_speaker.Speak(
            text,
            SVS_FLAGS_ASYNC,
        )

    def _wait_until_done(self) -> None:
        if not self._sapi_speaker:
            return

        try:
            self._sapi_speaker.WaitUntilDone(-1)
        except Exception as exc:
            logger.debug(
                f"SAPI WaitUntilDone warning: {exc}"
            )

    # ============================================================
    # WORKER
    # ============================================================

    def _worker(self):
        """
        Single persistent audio worker.

        Only this thread touches the SAPI COM object.
        """

        self._init_native_engine()

        while self.is_running:

            try:
                item = self.speech_queue.get(
                    timeout=self.worker_timeout
                )

            except queue.Empty:
                continue

            try:
                # ------------------------------------------------
                # SHUTDOWN
                # ------------------------------------------------

                if item == SENTINEL_SHUTDOWN:
                    break

                # ------------------------------------------------
                # SYNCHRONIZATION BARRIER
                # ------------------------------------------------

                if item == SENTINEL_SYNC:
                    self._wait_until_done()
                    self._set_speaking(False)
                    continue

                if not isinstance(item, str):
                    continue

                text = item.strip()

                if not text:
                    continue

                self._set_speaking(True)

                # ------------------------------------------------
                # Native SAPI
                # ------------------------------------------------

                if self._sapi_speaker:
                    try:
                        self._sapi_speak_async(text)

                    except Exception as exc:
                        logger.error(
                            f"SAPI Async Speak error: {exc}"
                        )

                # ------------------------------------------------
                # pyttsx3 fallback
                # ------------------------------------------------

                elif self._pyttsx_engine:
                    try:
                        self._pyttsx_engine.say(text)
                        self._pyttsx_engine.runAndWait()

                    except Exception as exc:
                        logger.error(
                            f"pyttsx3 Speak error: {exc}"
                        )

            except Exception as exc:
                logger.error(
                    f"TTS Worker error: {exc}",
                    exc_info=True,
                )

                self._set_speaking(False)

            finally:
                self.speech_queue.task_done()

        self._set_speaking(False)

        # ========================================================
        # COM CLEANUP
        # ========================================================

        if self._com_initialized:
            try:
                import pythoncom

                pythoncom.CoUninitialize()

            except Exception as exc:
                logger.debug(
                    f"COM cleanup warning: {exc}"
                )

            self._com_initialized = False

    # ============================================================
    # QUEUE
    # ============================================================

    def _queue_chunk(
        self,
        text: str,
    ) -> bool:
        """
        Queue speech without blocking the LLM stream.
        """

        if not self.is_running:
            return False

        text = text.strip()

        if not text:
            return False

        try:
            self.speech_queue.put_nowait(
                text
            )
            return True

        except queue.Full:
            logger.warning(
                "TTS queue full; dropping speech chunk."
            )
            return False

    # ============================================================
    # LLM STREAMING
    # ============================================================

    def stream_llm_response(
        self,
        token_generator: Generator[str, None, None],
    ):
        """
        Streams generated text to SAPI while the LLM is still
        generating.

        First chunk is deliberately small for low perceived
        latency. Later chunks are larger to preserve natural
        speech flow.
        """

        buffer: List[str] = []
        first_chunk = True

        sentence_end = re.compile(
            r"[.!?]\s*$"
        )

        soft_boundary = re.compile(
            r"[,;:]\s*$"
        )

        try:
            for token in token_generator:

                if not self.is_running:
                    break

                if token is None:
                    continue

                buffer.append(token)

                current_text = "".join(
                    buffer
                ).strip()

                if not current_text:
                    continue

                words = current_text.split()
                word_count = len(words)

                sentence_complete = bool(
                    sentence_end.search(
                        current_text
                    )
                )

                soft_complete = bool(
                    soft_boundary.search(
                        current_text
                    )
                )

                # ------------------------------------------------
                # FIRST CHUNK
                # ------------------------------------------------

                if first_chunk:

                    if (
                        word_count
                        >= self.first_chunk_words
                        or (
                            sentence_complete
                            and word_count
                            >= self.first_sentence_min_words
                        )
                    ):
                        if self._queue_chunk(
                            current_text
                        ):
                            buffer.clear()
                            first_chunk = False

                    continue

                # ------------------------------------------------
                # NEXT CHUNKS
                # ------------------------------------------------

                should_flush = (
                    word_count
                    >= self.next_chunk_words
                    or (
                        sentence_complete
                        and word_count
                        >= self.next_sentence_min_words
                    )
                )

                if (
                    self.soft_boundary_enabled
                    and soft_complete
                    and word_count
                    >= self.soft_boundary_min_words
                ):
                    should_flush = True

                if should_flush:

                    if self._queue_chunk(
                        current_text
                    ):
                        buffer.clear()

            # ----------------------------------------------------
            # FINAL BUFFER
            # ----------------------------------------------------

            remaining = "".join(
                buffer
            ).strip()

            if (
                remaining
                and self.is_running
            ):
                self._queue_chunk(
                    remaining
                )

        except Exception as exc:
            logger.error(
                f"TTS LLM streaming error: {exc}",
                exc_info=True,
            )

        finally:
            if self.is_running:
                self._queue_chunk(
                    SENTINEL_SYNC
                )

    # ============================================================
    # STATIC SPEECH
    # ============================================================

    def speak(
        self,
        text: str,
    ):
        """
        Queue a normal non-LLM response.

        Existing behavior preserved.
        """

        if not self.is_running:
            return

        if not text:
            return

        text = text.strip()

        if not text:
            return

        self._queue_chunk(text)

        self._queue_chunk(
            SENTINEL_SYNC
        )

    # ============================================================
    # STOP
    # ============================================================

    def stop(self):
        """
        Immediately purge queued speech and native SAPI audio.
        """

        while True:
            try:
                self.speech_queue.get_nowait()
                self.speech_queue.task_done()

            except queue.Empty:
                break

        # Native SAPI purge.
        if self._sapi_speaker:
            try:
                self._sapi_speaker.Speak(
                    "",
                    SVSF_PURGE_BEFORE_SPEAK,
                )
            except Exception as exc:
                logger.debug(
                    f"SAPI purge warning: {exc}"
                )

        # pyttsx3 fallback purge.
        if self._pyttsx_engine:
            try:
                self._pyttsx_engine.stop()
            except Exception:
                pass

        self._set_speaking(False)

    # ============================================================
    # SHUTDOWN
    # ============================================================

    def shutdown(self):
        """
        Cleanly terminate the worker thread and audio engine.
        """

        if not self.is_running:
            return

        self.stop()

        self.is_running = False

        # Wake the worker.
        try:
            self.speech_queue.put_nowait(
                SENTINEL_SHUTDOWN
            )

        except queue.Full:
            self.stop()

            try:
                self.speech_queue.put_nowait(
                    SENTINEL_SHUTDOWN
                )
            except queue.Full:
                pass

        if self.worker_thread.is_alive():
            self.worker_thread.join(
                timeout=self.shutdown_join_timeout
            )


TTS = StreamingTTS