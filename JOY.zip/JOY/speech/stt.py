# ==============================================================================
# Imports
# ==============================================================================

import collections
import contextlib
import difflib
import logging
import os
from pathlib import Path
import queue
import re
import sys
import threading
import time
from typing import Callable, Deque, List, Optional, Tuple

import numpy as np
from scipy import signal
import sounddevice as sd
import torch
from transformers import (
    AutoProcessor,
    MoonshineStreamingForConditionalGeneration,
    logging as hf_logging,
)

# ==============================================================================
# Path & Local Imports
# ==============================================================================

PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.append(str(PROJECT_ROOT))

import config
from speech.speaker import SpeakerVerifier

# ==============================================================================
# Logging & CPU Configuration
# ==============================================================================

hf_logging.set_verbosity_error()
logger = logging.getLogger(__name__)

_DEVNULL = open(os.devnull, "w", encoding="utf-8")

try:
    torch.set_num_threads(4)
    torch.set_num_interop_threads(2)
    torch.set_flush_denormal(True)
except Exception:
    pass

# ==============================================================================
# Text & Number Normalization Constants
# ==============================================================================

WORD_TO_DIGIT = {
    "zero": "0", "one": "1", "two": "2", "three": "3", "four": "4",
    "five": "5", "six": "6", "seven": "7", "eight": "8", "nine": "9",
    "ten": "10", "eleven": "11", "twelve": "12", "thirteen": "13",
    "fourteen": "14", "fifteen": "15", "sixteen": "16", "seventeen": "17",
    "eighteen": "18", "nineteen": "19", "twenty": "20",
}

_DIGIT_MAP = {**WORD_TO_DIGIT, **{str(i): str(i) for i in range(10)}}

INDIAN_MATH_PATTERNS = [
    (
        re.compile(r"(\b\d+)\s+(?:into|times|multiplied by)\s+(\d+\b)", re.IGNORECASE),
        r"\1 * \2",
    ),
    (
        re.compile(r"(\b\d+)\s+(?:upon|divided by|divide by)\s+(\d+\b)", re.IGNORECASE),
        r"\1 / \2",
    ),
    (
        re.compile(r"(\b\d+)\s+plus\s+(\d+\b)", re.IGNORECASE),
        r"\1 + \2",
    ),
    (
        re.compile(r"(\b\d+)\s+minus\s+(\d+\b)", re.IGNORECASE),
        r"\1 - \2",
    ),
]

DOUBLE_PATTERN = re.compile(
    r"\bdouble\s+(?:([0-9])|(zero|one|two|three|four|five|six|seven|eight|nine))\b",
    re.IGNORECASE,
)

TRIPLE_PATTERN = re.compile(
    r"\btriple\s+(?:([0-9])|(zero|one|two|three|four|five|six|seven|eight|nine))\b",
    re.IGNORECASE,
)

CLEAN_CHARS_REGEX = re.compile(r"[^a-zA-Z0-9+*/\-\s]")
MULTIPLE_SPACES_REGEX = re.compile(r"\s+")
WORD_BOUND_REGEX = re.compile(r"\b[\w]+\b")

# ==============================================================================
# Filters & Heuristics Vocabularies
# ==============================================================================

HALLUCINATIONS = {
    "thank you",
    "thank you thank you",
    "thank you so much",
    "thank you so much thank you so much",
    "subtitles",
    "subtitles subtitles",
    "amaraorg",
    "amara org",
    "silence silence",
    "watching watching",
    "see you see you",
    "thanks for watching",
    "thank you for watching",
}

WEAK_SOUND_UTTERANCES = {
    "uh", "um", "umm", "hmm", "hm", "mmm", "mm", "ah", "eh", "er",
}

SAFE_CORRECTIONS = {
    "nodepad": "notepad",
    "note pad": "notepad",
    "calci": "calculator",
    "calcium": "calculator",
    "calcular": "calculator",
    "deskutop": "desktop",
    "discotop": "desktop",
    "disco top": "desktop",
    "desk top": "desktop",
    "mine craft": "minecraft",
    "micro soft edge": "microsoft edge",
    "you tube": "youtube",
    "chat g p t": "chatgpt",
    "chat gpt": "chatgpt",
    "whats app": "whatsapp",
    "linked in": "linkedin",
}

_SAFE_CORRECTIONS_MAP = {k.lower(): v for k, v in SAFE_CORRECTIONS.items()}
_SAFE_CORRECTIONS_REGEX = re.compile(
    r"\b(" + "|".join(re.escape(k) for k in sorted(_SAFE_CORRECTIONS_MAP.keys(), key=len, reverse=True)) + r")\b",
    re.IGNORECASE,
)

SYSTEM_METRIC_PHRASES = {
    "ram", "ram usage", "memory", "memory usage",
    "cpu", "cpu usage", "cpu utilization",
    "gpu", "gpu usage", "gpu utilization",
    "system usage", "disk usage", "disk space",
    "battery", "battery percentage", "battery level", "battery status", "battery time",
    "wifi", "wi fi", "wifi status", "internet", "internet status", "uptime",
}

LOW_VALUE_PREFIXES = {
    "six", "seven", "eight", "nine", "one", "two", "three", "four", "five",
    "0", "1", "2", "3", "4", "5", "6", "7", "8", "9",
}

# ==============================================================================
# Text Normalization & Transcript Repair Pipeline
# ==============================================================================

def clean_text(text: str) -> str:
    """Fast baseline text normalization."""
    if not text:
        return ""

    text_lower = text.lower().strip()

    # Double conversion
    if "double" in text_lower:
        def _double_replace(match: re.Match) -> str:
            token = (match.group(1) or match.group(2)).lower()
            value = _DIGIT_MAP.get(token, token)
            return value * 2

        text_lower = DOUBLE_PATTERN.sub(_double_replace, text_lower)

    # Triple conversion
    if "triple" in text_lower:
        def _triple_replace(match: re.Match) -> str:
            token = (match.group(1) or match.group(2)).lower()
            value = _DIGIT_MAP.get(token, token)
            return value * 3

        text_lower = TRIPLE_PATTERN.sub(_triple_replace, text_lower)

    # Number words conversion
    words = text_lower.split()
    converted = [WORD_TO_DIGIT.get(word, word) for word in words]
    text_lower = " ".join(converted)

    # Math operators
    for pattern, replacement in INDIAN_MATH_PATTERNS:
        text_lower = pattern.sub(replacement, text_lower)

    # Character cleaning
    text_clean = CLEAN_CHARS_REGEX.sub("", text_lower)
    return MULTIPLE_SPACES_REGEX.sub(" ", text_clean).strip()


def _repair_metric_phrase(text: str) -> str:
    """Repair obvious ASR insertions around system metrics."""
    if not text:
        return ""

    words = text.split()
    if len(words) < 2:
        return text

    result = list(words)
    changed = True

    while changed:
        changed = False
        lower_words = [word.lower() for word in result]

        # Two-word metric detection
        for index in range(1, len(lower_words) - 1):
            phrase = f"{lower_words[index]} {lower_words[index + 1]}"
            if phrase not in SYSTEM_METRIC_PHRASES:
                continue

            previous = lower_words[index - 1]
            if previous in LOW_VALUE_PREFIXES:
                del result[index - 1]
                changed = True
                break

        if changed:
            continue

        # One-word metric detection
        for index in range(1, len(lower_words)):
            word = lower_words[index]
            if word not in SYSTEM_METRIC_PHRASES:
                continue

            previous = lower_words[index - 1]
            if previous in LOW_VALUE_PREFIXES:
                del result[index - 1]
                changed = True
                break

    return " ".join(result)


def _repair_common_asr_sequences(text: str) -> str:
    """Lightweight contextual repair for common Moonshine short-command mistakes."""
    if not text:
        return ""

    text = _repair_metric_phrase(text)
    words = text.split()
    if not words:
        return ""

    # Remove duplicated adjacent numeric junk before metrics
    while len(words) >= 2:
        first = words[0].lower()
        second = words[1].lower()

        if first in LOW_VALUE_PREFIXES and second in LOW_VALUE_PREFIXES:
            remaining = " ".join(words[2:]).lower()
            if any(phrase in remaining for phrase in SYSTEM_METRIC_PHRASES):
                words.pop(0)
                continue
        break

    text = " ".join(words)

    phrase_repairs = (
        ("ram usage usage", "ram usage"),
        ("cpu usage usage", "cpu usage"),
        ("gpu usage usage", "gpu usage"),
        ("battery battery", "battery"),
        ("memory usage usage", "memory usage"),
    )

    for bad, good in phrase_repairs:
        text = re.sub(rf"\b{re.escape(bad)}\b", good, text, flags=re.IGNORECASE)

    return text.strip()


def repair_transcript(text: str) -> str:
    """
    Full lightweight transcript repair pipeline.
    Flow: clean -> safe corrections -> contextual repair -> safe corrections
    """
    text = clean_text(text)
    if not text:
        return ""

    text = _SAFE_CORRECTIONS_REGEX.sub(
        lambda m: _SAFE_CORRECTIONS_MAP.get(m.group(0).lower(), m.group(0)), text
    )
    text = _repair_common_asr_sequences(text)
    text = _SAFE_CORRECTIONS_REGEX.sub(
        lambda m: _SAFE_CORRECTIONS_MAP.get(m.group(0).lower(), m.group(0)), text
    )

    return MULTIPLE_SPACES_REGEX.sub(" ", text).strip()

# ==============================================================================
# Audio DSP Pipeline
# ==============================================================================

class AudioProcessorPipeline:
    """Stable high-pass filtering with streaming filter state."""

    def __init__(self, sample_rate: int = 16000, highpass_cutoff: float = 70.0):
        self.sample_rate = int(sample_rate)
        nyquist = 0.5 * self.sample_rate
        normalized = highpass_cutoff / nyquist

        self.sos = signal.butter(4, normalized, btype="high", output="sos")
        self.zi = signal.sosfilt_zi(self.sos)

    def reset(self) -> None:
        self.zi = signal.sosfilt_zi(self.sos)

    def filter(self, audio_block: np.ndarray) -> np.ndarray:
        if audio_block is None or len(audio_block) == 0:
            return np.zeros(0, dtype=np.float32)

        if not isinstance(audio_block, np.ndarray) or audio_block.dtype != np.float32:
            audio_block = np.asarray(audio_block, dtype=np.float32)

        filtered, self.zi = signal.sosfilt(self.sos, audio_block, zi=self.zi)
        return filtered.astype(np.float32, copy=False)

    @staticmethod
    def stabilize_level(audio: np.ndarray) -> np.ndarray:
        if audio is None or len(audio) == 0:
            return np.zeros(0, dtype=np.float32)

        if audio.dtype != np.float32 or not audio.flags.c_contiguous:
            audio = np.ascontiguousarray(audio, dtype=np.float32)

        peak = float(np.max(np.abs(audio)))
        if peak <= 1e-6:
            return audio

        if peak > 0.95:
            audio *= 0.95 / peak

        return np.clip(audio, -1.0, 1.0, out=audio)

# ==============================================================================
# Fast Adaptive VAD
# ==============================================================================

class RobustVAD:
    """Fast adaptive RMS VAD."""

    def __init__(self, start_threshold: float = 0.014, hold_threshold: float = 0.008):
        self.base_start_threshold = float(start_threshold)
        self.base_hold_threshold = float(hold_threshold)
        self.noise_floor = self.base_start_threshold * 0.55
        self.noise_alpha = 0.965
        self.required_speech_blocks = 2
        self.consecutive_speech_blocks = 0
        self.last_rms = 0.0

    @staticmethod
    def calculate_rms(audio: np.ndarray) -> float:
        if audio is None or len(audio) == 0:
            return 0.0
        return float(np.sqrt(np.dot(audio, audio) / len(audio)))

    def check_speech(self, audio: np.ndarray, currently_active: bool) -> Tuple[bool, float]:
        rms = self.calculate_rms(audio)
        self.last_rms = rms

        if currently_active:
            threshold = max(self.base_hold_threshold, self.noise_floor * 1.30)
            if rms >= threshold:
                self.consecutive_speech_blocks += 1
            else:
                self.consecutive_speech_blocks = 0
            return rms >= threshold, rms

        # Waiting for speech start
        start_threshold = max(self.base_start_threshold, self.noise_floor * 2.15)
        raw_speech = rms >= start_threshold

        if raw_speech:
            self.consecutive_speech_blocks += 1
        else:
            self.consecutive_speech_blocks = 0
            if rms < start_threshold * 0.75:
                self.noise_floor = (self.noise_alpha * self.noise_floor) + ((1.0 - self.noise_alpha) * rms)
                self.noise_floor = min(self.noise_floor, self.base_start_threshold * 1.5)

        confirmed = self.consecutive_speech_blocks >= self.required_speech_blocks
        return confirmed, rms

    def reset(self) -> None:
        self.noise_floor = self.base_start_threshold * 0.55
        self.consecutive_speech_blocks = 0
        self.last_rms = 0.0

# ==============================================================================
# JOY STT Engine
# ==============================================================================

class STT:

    def __init__(
        self,
        on_partial_text: Optional[Callable[[str], None]] = None,
        on_final_text: Optional[Callable[[str], None]] = None,
    ):
        logger.info("Initializing JOY Moonshine STT Engine...")
        self.on_partial_text = on_partial_text
        self.on_final_text = on_final_text

        # Configuration
        self.model_name = config.STT_CONFIG["model"]
        self.model_path = config.STT_CONFIG["model_path"]
        self.sample_rate = int(config.STT_CONFIG["sample_rate"])
        self.block_size = int(config.STT_CONFIG["block_size"])
        self.energy_threshold = float(config.STT_CONFIG["energy_threshold"])
        self.silence_duration = float(config.STT_CONFIG["silence_duration"])
        self.update_interval = float(config.STT_CONFIG["partial_interval"])
        self.preroll_blocks = int(config.STT_CONFIG["preroll_blocks"])

        # Endpointing
        self.min_speech_duration = 0.45
        self.max_speech_duration = 15.0
        self.final_silence_duration = max(0.28, min(self.silence_duration, 0.45))
        self.max_partial_audio_seconds = 4.0
        self.min_partial_audio_seconds = 0.40

        # Microphone Gating
        self._is_muted = False
        self._unmute_timestamp = 0.0
        self._mute_lock = threading.Lock()

        # Speaker Verification
        self.speaker_verifier = SpeakerVerifier(
            sample_rate=self.sample_rate,
            profile_path=Path(__file__).resolve().parent / "speaker_profile.npy",
            threshold=0.50,
        )
        self.speaker_verification_enabled = self.speaker_verifier.enrolled
        self.speaker_verified_for_utterance = False
        self.min_speaker_verification_seconds = 0.85

        if self.speaker_verification_enabled:
            logger.info("Speaker verification ENABLED.")
        else:
            logger.warning("No speaker profile found. JOY speaker verification is DISABLED.")

        # Moonshine Processor & Model Loading
        self.processor = AutoProcessor.from_pretrained(
            self.model_name,
            trust_remote_code=True,
            cache_dir=self.model_path,
            local_files_only=True,
        )

        raw_model = MoonshineStreamingForConditionalGeneration.from_pretrained(
            self.model_name,
            trust_remote_code=True,
            cache_dir=self.model_path,
            torch_dtype=torch.float32,
            local_files_only=True,
        )
        raw_model.eval()

        logger.info("Applying INT8 Dynamic Quantization for CPU...")
        self.model = torch.ao.quantization.quantize_dynamic(
            raw_model,
            {torch.nn.Linear},
            dtype=torch.qint8,
        )
        self.model.eval()
        self.device = torch.device("cpu")

        self._warmup()

        # DSP & VAD
        self.dsp = AudioProcessorPipeline(sample_rate=self.sample_rate, highpass_cutoff=70.0)
        self.vad = RobustVAD(
            start_threshold=self.energy_threshold,
            hold_threshold=self.energy_threshold * 0.58,
        )

        # Queues & Threads
        self.stream = None
        self.raw_audio_queue = queue.Queue(maxsize=48)
        self.recognizer_queue = queue.Queue(maxsize=4)
        self.running = False
        self.audio_thread: Optional[threading.Thread] = None
        self.recognizer_thread: Optional[threading.Thread] = None

        # Buffers & Timing States
        self.preroll_buffer: Deque[np.ndarray] = collections.deque(maxlen=self.preroll_blocks)
        self.current_audio: List[np.ndarray] = []
        self.is_speaking = False
        self.speech_started_at = 0.0
        self.last_spoken_time = 0.0
        self.last_partial_time = 0.0

        # Partial Hypothesis State
        self.partial_history: Deque[str] = collections.deque(maxlen=5)
        self.last_partial_text = ""
        self.best_partial_candidate = ""
        self.stable_partial_text = ""
        self.partial_repeat_count = 0
        self.latest_transcript = ""

        # Final Duplicate Protection
        self.last_final_text = ""
        self.last_final_timestamp = 0.0

        logger.info("JOY Moonshine STT loaded successfully.")

    # ==========================================================================
    # Speaker Verification
    # ==========================================================================

    def _verify_current_speaker(self, audio: np.ndarray) -> bool:
        if not self.speaker_verification_enabled:
            logger.warning("Speaker verification requested but no enrolled profile exists.")
            return False

        if self.speaker_verified_for_utterance:
            return True

        if audio is None or len(audio) == 0:
            return False

        duration = len(audio) / self.sample_rate
        if duration < self.min_speaker_verification_seconds:
            logger.debug("Speaker audio too short: %.2fs", duration)
            return False

        accepted, score = self.speaker_verifier.verify(audio)
        if score is None:
            logger.warning("Speaker verification produced no score.")
            return False

        if accepted:
            self.speaker_verified_for_utterance = True
            logger.info("Speaker VERIFIED | score=%.4f", score)
            return True

        logger.info("Speaker REJECTED | score=%.4f", score)
        return False

    # ==========================================================================
    # Mute Controls & Queue Utilities
    # ==========================================================================

    def mute(self) -> None:
        with self._mute_lock:
            self._is_muted = True
            self._clear_speech_state()
            self._flush_queue(self.raw_audio_queue)
            self._flush_queue(self.recognizer_queue)
            self.dsp.reset()
            self.vad.reset()

    def unmute(self, cooldown_seconds: float = 0.25) -> None:
        with self._mute_lock:
            self._unmute_timestamp = time.time() + cooldown_seconds
            self._clear_speech_state()
            self.dsp.reset()
            self.vad.reset()
            self._flush_queue(self.raw_audio_queue)
            self._flush_queue(self.recognizer_queue)
            self._is_muted = False

    def is_muted(self) -> bool:
        with self._mute_lock:
            return self._is_muted or time.time() < self._unmute_timestamp

    @staticmethod
    def _flush_queue(q: queue.Queue) -> None:
        while True:
            try:
                q.get_nowait()
            except queue.Empty:
                break

    # ==========================================================================
    # Model Warmup & Lifecycle
    # ==========================================================================

    def _warmup(self) -> None:
        dummy_audio = np.zeros(self.sample_rate, dtype=np.float32)
        inputs = self.processor(
            audio=dummy_audio,
            sampling_rate=self.sample_rate,
            return_tensors="pt",
        )
        with (
            torch.inference_mode(),
            contextlib.redirect_stdout(_DEVNULL),
            contextlib.redirect_stderr(_DEVNULL),
        ):
            self.model.generate(
                **inputs,
                max_new_tokens=4,
                num_beams=1,
                do_sample=False,
                use_cache=True,
            )

    def start(self) -> None:
        if self.running:
            logger.warning("STT is already running.")
            return

        self.running = True
        self.audio_thread = threading.Thread(
            target=self._audio_worker,
            daemon=True,
            name="JOY-STT-Audio",
        )
        self.recognizer_thread = threading.Thread(
            target=self._recognizer_worker,
            daemon=True,
            name="JOY-STT-Recognizer",
        )

        self.audio_thread.start()
        self.recognizer_thread.start()

        try:
            self.stream = sd.InputStream(
                samplerate=self.sample_rate,
                blocksize=self.block_size,
                channels=1,
                dtype="float32",
                callback=self.callback,
            )
            self.stream.start()
        except Exception:
            self.running = False
            logger.error("Failed to start microphone.", exc_info=True)
            raise

        logger.info("JOY STT Engine & Microphone started.")

    def stop(self) -> None:
        self.running = False
        if self.stream is not None:
            try:
                self.stream.stop()
                self.stream.close()
            except Exception:
                pass
            self.stream = None

        if self.audio_thread is not None and self.audio_thread.is_alive():
            self.audio_thread.join(timeout=1.0)

        if self.recognizer_thread is not None and self.recognizer_thread.is_alive():
            self.recognizer_thread.join(timeout=1.5)

        self._flush_queue(self.raw_audio_queue)
        self._flush_queue(self.recognizer_queue)
        self._clear_speech_state()
        logger.info("JOY STT Engine & Microphone stopped.")

    def callback(self, indata, frames, time_info, status) -> None:
        if not self.running or self.is_muted():
            return

        if status:
            logger.debug("Input stream status: %s", status)

        try:
            audio = indata[:, 0].astype(np.float32, copy=True)
            self.raw_audio_queue.put_nowait(audio)
        except queue.Full:
            pass
        except Exception as exc:
            logger.debug("Audio callback error: %s", exc)

    # ==========================================================================
    # Text Analysis Utilities
    # ==========================================================================

    @staticmethod
    def _word_count(text: str) -> int:
        return len(WORD_BOUND_REGEX.findall(text))

    @staticmethod
    def _is_repetitive(text: str) -> bool:
        words = text.split()
        total = len(words)
        if total < 3:
            return False

        if len(set(words)) == 1:
            return True

        for first, second in zip(words, words[1:]):
            if first == second and len(first) > 1:
                return True

        if total >= 4:
            max_size = min(5, total // 2 + 1)
            for size in range(1, max_size):
                if words[:size] == words[size: size * 2]:
                    return True

        return False

    @staticmethod
    def _similarity(first: str, second: str) -> float:
        if not first or not second:
            return 0.0
        return difflib.SequenceMatcher(None, first, second).quick_ratio()

    # ==========================================================================
    # Transcription & Quality Filter
    # ==========================================================================

    def _is_bad_transcript(
        self,
        text: str,
        audio_seconds: float,
        rms_energy: float,
        final: bool,
    ) -> bool:
        if not text:
            return True

        text = repair_transcript(text)
        if not text:
            return True

        if text in HALLUCINATIONS or text in WEAK_SOUND_UTTERANCES:
            return True

        if self._is_repetitive(text):
            return True

        words = self._word_count(text)

        # Drop excessive token generation from short clips
        if audio_seconds < 0.42 and words >= 5:
            return True

        if final and audio_seconds >= 0.50 and rms_energy < self.energy_threshold * 0.28 and words <= 2:
            return True

        if (
            final
            and audio_seconds < self.min_speech_duration
            and words == 1
            and rms_energy < self.energy_threshold * 1.30
        ):
            return True

        return False

    def transcribe(self, audio: Optional[np.ndarray] = None, final: bool = False) -> str:
        if audio is None or len(audio) == 0:
            return ""

        if not isinstance(audio, np.ndarray) or audio.dtype != np.float32:
            audio = np.asarray(audio, dtype=np.float32)

        audio_seconds = len(audio) / self.sample_rate
        if final and audio_seconds < 0.25:
            return ""

        rms_energy = float(np.sqrt(np.dot(audio, audio) / len(audio)))
        if rms_energy < self.energy_threshold * 0.25:
            return ""

        audio = self.dsp.stabilize_level(audio)
        inputs = self.processor(audio=audio, sampling_rate=self.sample_rate, return_tensors="pt")

        estimated_tokens = int(audio_seconds * 4.5) + 3
        if final:
            max_tokens = min(64, max(12, estimated_tokens))
        else:
            max_tokens = min(20, max(6, estimated_tokens))

        with (
            torch.inference_mode(),
            contextlib.redirect_stdout(_DEVNULL),
            contextlib.redirect_stderr(_DEVNULL),
        ):
            generated_ids = self.model.generate(
                **inputs,
                max_new_tokens=max_tokens,
                num_beams=1,
                do_sample=False,
                use_cache=True,
                repetition_penalty=1.15,
                no_repeat_ngram_size=3,
            )

        raw_text = self.processor.batch_decode(generated_ids, skip_special_tokens=True)[0]
        return repair_transcript(raw_text)

    # ==========================================================================
    # Partial & Final Selection
    # ==========================================================================

    def _process_partial(self, text: str) -> str:
        text = repair_transcript(text)
        if not text:
            return ""

        if self.last_partial_text == text:
            self.partial_repeat_count += 1
        else:
            self.partial_repeat_count = 1

        self.last_partial_text = text
        self.partial_history.append(text)

        stable = self.partial_repeat_count >= 2
        if len(self.partial_history) >= 3:
            recent = list(self.partial_history)[-3:]
            sim1 = self._similarity(recent[0], recent[1])
            sim2 = self._similarity(recent[1], recent[2])
            if sim1 >= 0.90 and sim2 >= 0.90:
                stable = True

        if stable:
            self.stable_partial_text = text
            if len(text) >= len(self.best_partial_candidate) and len(text) <= len(self.best_partial_candidate) + 80:
                self.best_partial_candidate = text

        return text

    def _select_final_text(
        self,
        final_text: str,
        audio_seconds: float,
        rms_energy: float,
    ) -> str:
        final_text = repair_transcript(final_text)
        partial_text = repair_transcript(self.best_partial_candidate)

        if not final_text:
            return partial_text
        if not partial_text:
            return final_text

        final_bad = self._is_bad_transcript(final_text, audio_seconds, rms_energy, True)
        partial_bad = self._is_bad_transcript(partial_text, audio_seconds, rms_energy, True)

        if final_bad and not partial_bad:
            return partial_text

        similarity = self._similarity(final_text, partial_text)
        if similarity >= 0.72:
            return final_text

        if self._word_count(final_text) == 1 and self._word_count(partial_text) >= 2 and similarity < 0.60:
            return partial_text

        final_repaired = repair_transcript(final_text)
        partial_repaired = repair_transcript(partial_text)

        if final_repaired != final_text and final_repaired:
            return final_repaired

        if partial_repaired != partial_text and partial_repaired:
            return partial_repaired

        return final_text

    def _clear_speech_state(self) -> None:
        self.current_audio.clear()
        self.preroll_buffer.clear()
        self.is_speaking = False
        self.speech_started_at = 0.0
        self.last_spoken_time = 0.0
        self.last_partial_time = 0.0
        self.partial_history.clear()
        self.last_partial_text = ""
        self.best_partial_candidate = ""
        self.stable_partial_text = ""
        self.partial_repeat_count = 0
        self.speaker_verified_for_utterance = False

    # ==========================================================================
    # Audio Worker
    # ==========================================================================

    def _audio_worker(self) -> None:
        while self.running:
            try:
                raw_audio = self.raw_audio_queue.get(timeout=0.05)
            except queue.Empty:
                continue

            if self.is_muted():
                continue

            try:
                now = time.time()
                filtered_audio = self.dsp.filter(raw_audio)
                speech_detected, rms = self.vad.check_speech(filtered_audio, self.is_speaking)

                # Waiting for speech start
                if not self.is_speaking:
                    self.preroll_buffer.append(filtered_audio)
                    if speech_detected:
                        self.is_speaking = True
                        self.speech_started_at = now
                        self.last_spoken_time = now
                        self.last_partial_time = 0.0
                        self.speaker_verified_for_utterance = False

                        self.current_audio = list(self.preroll_buffer) + [filtered_audio]
                        self.partial_history.clear()
                        self.last_partial_text = ""
                        self.best_partial_candidate = ""
                        self.stable_partial_text = ""
                        self.partial_repeat_count = 0
                        logger.debug("Speech activity confirmed.")
                    continue

                # Active speech tracking
                self.current_audio.append(filtered_audio)
                if speech_detected:
                    self.last_spoken_time = now

                speech_duration = now - self.speech_started_at

                # Partial decoding interval trigger
                if now - self.last_partial_time >= self.update_interval:
                    total_samples = sum(len(chunk) for chunk in self.current_audio)
                    current_seconds = total_samples / self.sample_rate

                    if current_seconds >= self.min_partial_audio_seconds:
                        self.last_partial_time = now
                        combined = np.concatenate(self.current_audio)
                        max_live_samples = int(self.max_partial_audio_seconds * self.sample_rate)

                        if len(combined) > max_live_samples:
                            combined = combined[-max_live_samples:]

                        try:
                            if self.recognizer_queue.qsize() < 2:
                                self.recognizer_queue.put_nowait((combined, False))
                        except queue.Full:
                            pass

                # Max utterance limit reached
                if speech_duration >= self.max_speech_duration:
                    logger.debug("Maximum utterance duration reached.")
                    self._queue_final_audio()
                    continue

                # Fast endpointing after trailing silence
                if now - self.last_spoken_time >= self.final_silence_duration:
                    self._queue_final_audio()

            except Exception as exc:
                logger.error("STT audio worker error: %s", exc, exc_info=True)

    def _queue_final_audio(self) -> None:
        if not self.current_audio:
            self._clear_speech_state()
            return

        combined = np.concatenate(self.current_audio)
        try:
            if self.recognizer_queue.full():
                self._flush_queue(self.recognizer_queue)
            self.recognizer_queue.put_nowait((combined, True))
        except queue.Full:
            logger.warning("Recognizer queue full; dropping final audio.")

        self._clear_speech_state()

    # ==========================================================================
    # Recognizer Worker
    # ==========================================================================

    def _recognizer_worker(self) -> None:
        while self.running:
            try:
                item = self.recognizer_queue.get(timeout=0.05)
            except queue.Empty:
                continue

            if self.is_muted():
                continue

            audio, final = item

            # Coalesce partial hypotheses
            if not final:
                while True:
                    try:
                        next_item = self.recognizer_queue.get_nowait()
                    except queue.Empty:
                        break

                    next_audio, next_final = next_item
                    audio = next_audio
                    final = next_final
                    if final:
                        break

            try:
                if audio is None or len(audio) == 0:
                    continue

                audio_seconds = len(audio) / self.sample_rate
                rms_energy = float(np.sqrt(np.dot(audio, audio) / len(audio)))

                text = self.transcribe(audio, final=final)
                if not text:
                    if final:
                        self.latest_transcript = ""
                        self.best_partial_candidate = ""
                    continue

                # Quality Filter
                if self._is_bad_transcript(text, audio_seconds, rms_energy, final):
                    logger.debug("Rejected %s transcript: %r", "final" if final else "partial", text)
                    if final:
                        fallback = self.best_partial_candidate
                        if fallback and not self._is_bad_transcript(fallback, audio_seconds, rms_energy, True):
                            text = repair_transcript(fallback)
                        else:
                            self.latest_transcript = ""
                            continue
                    else:
                        continue

                # Handle Partial Output
                if not final:
                    display_text = self._process_partial(text)
                    if not display_text or display_text == self.latest_transcript:
                        continue

                    self.latest_transcript = display_text
                    if self.on_partial_text:
                        self.on_partial_text(display_text)
                    else:
                        print(f"\r\033[K\033[36m[💬 Live]: {display_text}\033[0m", end="", flush=True)
                    continue

                # Handle Final Output
                final_text = self._select_final_text(text, audio_seconds, rms_energy)
                final_text = repair_transcript(final_text)

                if not final_text:
                    self.latest_transcript = ""
                    continue

                if self._is_bad_transcript(final_text, audio_seconds, rms_energy, True):
                    logger.debug("Final transcript cancelled: %r", final_text)
                    self.latest_transcript = ""
                    continue

                if self.speaker_verification_enabled:
                    verified = self._verify_current_speaker(audio)
                    if not verified:
                        logger.info("Final transcript rejected because speaker was not verified: %r", final_text)
                        self.latest_transcript = ""
                        continue

                now = time.time()
                if final_text == self.last_final_text and (now - self.last_final_timestamp) < 1.0:
                    logger.debug("Duplicate final transcript suppressed: %r", final_text)
                    continue

                self.last_final_text = final_text
                self.last_final_timestamp = now
                self.latest_transcript = final_text

                logger.info("Final Transcript: %s", final_text)
                if self.on_final_text:
                    self.on_final_text(final_text)
                else:
                    print(f"\r\033[K\033[32m[You Said]: {final_text}\033[0m", flush=True)

                self.partial_history.clear()
                self.last_partial_text = ""
                self.best_partial_candidate = ""
                self.stable_partial_text = ""
                self.partial_repeat_count = 0

            except Exception as exc:
                logger.error("STT Error during inference: %s", exc, exc_info=True)
                self.latest_transcript = ""
                self.partial_history.clear()
                self.last_partial_text = ""
                self.best_partial_candidate = ""
                self.stable_partial_text = ""
                self.partial_repeat_count = 0

    # ==========================================================================
    # Shutdown
    # ==========================================================================

    def shutdown(self) -> None:
        self.stop()
        try:
            _DEVNULL.close()
        except Exception:
            pass