import logging
import time
from pathlib import Path

import numpy as np
import sounddevice as sd

from speaker import SpeakerVerifier


# ============================================================
# SETTINGS
# ============================================================

SAMPLE_RATE = 16000
CHANNELS = 1

# Enrollment
SAMPLE_DURATION = 5.0
NUMBER_OF_SAMPLES = 10

# Verification
VERIFICATION_DURATION = 4.0
NUMBER_OF_TESTS = 5

# Audio quality
MIN_RMS = 0.005

# Initial experimental threshold.
# We will tune this after seeing your real ERes2NetV2 scores.
INITIAL_THRESHOLD = 0.50

OUTPUT_PROFILE = (
    Path(__file__).resolve().parent
    / "speaker_profile.npy"
)


# ============================================================
# LOGGING
# ============================================================

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
)

logger = logging.getLogger(
    "JOY-Speaker-Enrollment"
)


# ============================================================
# RECORD AUDIO
# ============================================================

def record_sample(
    duration: float,
) -> np.ndarray:

    print()
    print("Speak naturally...")

    audio = sd.rec(
        int(
            duration * SAMPLE_RATE
        ),
        samplerate=SAMPLE_RATE,
        channels=CHANNELS,
        dtype="float32",
    )

    sd.wait()

    audio = audio[:, 0]

    return np.asarray(
        audio,
        dtype=np.float32,
    )


# ============================================================
# RMS
# ============================================================

def calculate_rms(
    audio: np.ndarray,
) -> float:

    if audio is None or len(audio) == 0:
        return 0.0

    return float(
        np.sqrt(
            np.mean(
                np.square(audio)
            )
        )
    )


# ============================================================
# SCORE ANALYSIS
# ============================================================

def analyze_scores(
    scores: list[float],
    threshold: float,
) -> None:

    if not scores:

        print(
            "No valid verification scores were produced."
        )

        return

    values = np.asarray(
        scores,
        dtype=np.float32,
    )

    average = float(
        np.mean(values)
    )

    median = float(
        np.median(values)
    )

    minimum = float(
        np.min(values)
    )

    maximum = float(
        np.max(values)
    )

    std_dev = float(
        np.std(values)
    )

    passed = int(
        np.sum(
            values >= threshold
        )
    )

    print()
    print("=" * 60)
    print("VOICE SCORE ANALYSIS")
    print("=" * 60)

    print(
        f"Average score : {average:.4f}"
    )

    print(
        f"Median score  : {median:.4f}"
    )

    print(
        f"Minimum score : {minimum:.4f}"
    )

    print(
        f"Maximum score : {maximum:.4f}"
    )

    print(
        f"Std deviation : {std_dev:.4f}"
    )

    print(
        f"Threshold     : {threshold:.4f}"
    )

    print(
        f"Passed        : {passed}/{len(scores)}"
    )

    print()

    if minimum >= threshold:

        print(
            "✅ All self-tests passed."
        )

    elif average >= threshold:

        print(
            "⚠️ Average is above the threshold, "
            "but at least one self-test failed."
        )

    else:

        print(
            "❌ Your own verification scores are "
            "mostly below the threshold."
        )

    print()

    print(
        "Keep these scores. We will use them to "
        "tune JOY's final verification threshold."
    )


# ============================================================
# MAIN
# ============================================================

def main():

    print()
    print("=" * 64)
    print("             JOY ERes2NetV2 ENROLLMENT")
    print("=" * 64)
    print()

    print(
        f"JOY will learn your voice from "
        f"{NUMBER_OF_SAMPLES} samples."
    )

    print()
    print("IMPORTANT:")
    print("• Use the same microphone JOY uses.")
    print("• Sit in your normal position.")
    print("• Speak at your normal volume.")
    print("• Do not whisper.")
    print("• Do not shout.")
    print("• Use different natural phrases.")
    print("• Keep background noise low.")

    print()
    print("Example phrases:")

    print(
        '  "Hello JOY, open my browser."'
    )

    print(
        '  "JOY, what is the time?"'
    )

    print(
        '  "Open Notepad for me."'
    )

    print(
        '  "What is the weather today?"'
    )

    print(
        '  "JOY, how are you doing?"'
    )

    print()

    input(
        "Press ENTER when you are ready..."
    )

    # ========================================================
    # VERIFIER
    # ========================================================

    print()
    print(
        "Loading ERes2NetV2 speaker model..."
    )

    verifier = SpeakerVerifier(
        sample_rate=SAMPLE_RATE,
        profile_path=str(
            OUTPUT_PROFILE
        ),
        threshold=INITIAL_THRESHOLD,
    )

    # ========================================================
    # COLLECT ENROLLMENT SAMPLES
    # ========================================================

    samples: list[np.ndarray] = []

    while (
        len(samples)
        < NUMBER_OF_SAMPLES
    ):

        index = len(samples) + 1

        print()
        print("-" * 60)

        print(
            f"ENROLLMENT SAMPLE "
            f"{index}/{NUMBER_OF_SAMPLES}"
        )

        print("-" * 60)

        if index <= 3:

            print(
                "Speak at your normal voice."
            )

        elif index <= 6:

            print(
                "Use a different natural phrase."
            )

        else:

            print(
                "Use slightly different "
                "speed/intonation."
            )

        input(
            "Press ENTER, then speak..."
        )

        time.sleep(0.25)

        audio = record_sample(
            SAMPLE_DURATION
        )

        level = calculate_rms(
            audio
        )

        print(
            f"Recorded RMS: {level:.5f}"
        )

        if level < MIN_RMS:

            print(
                "⚠️ Recording is too quiet."
            )

            print(
                "This sample will be repeated."
            )

            continue

        samples.append(
            audio
        )

        print(
            "✓ Sample accepted."
        )

        print(
            f"Progress: "
            f"{len(samples)}/{NUMBER_OF_SAMPLES}"
        )

    # ========================================================
    # CREATE PROFILE
    # ========================================================

    print()
    print("=" * 64)
    print("              CREATING ERes2NetV2 PROFILE")
    print("=" * 64)
    print()

    success = (
        verifier.create_profile(
            samples
        )
    )

    if not success:

        print()
        print(
            "❌ Failed to create speaker profile."
        )

        return

    print()
    print(
        "✅ ERes2NetV2 speaker profile created."
    )

    print()
    print(
        f"Profile:"
    )

    print(
        OUTPUT_PROFILE
    )

    # ========================================================
    # SELF VERIFICATION
    # ========================================================

    print()
    print("=" * 64)
    print("              SELF VERIFICATION TEST")
    print("=" * 64)
    print()

    print(
        f"We will perform {NUMBER_OF_TESTS} "
        "tests using your voice."
    )

    print(
        "Speak naturally each time."
    )

    scores: list[float] = []

    for test_index in range(
        1,
        NUMBER_OF_TESTS + 1,
    ):

        print()
        print("-" * 60)

        print(
            f"VERIFICATION TEST "
            f"{test_index}/{NUMBER_OF_TESTS}"
        )

        print("-" * 60)

        input(
            'Press ENTER and say something like '
            '"Hello JOY"...'
        )

        time.sleep(0.25)

        test_audio = record_sample(
            VERIFICATION_DURATION
        )

        level = calculate_rms(
            test_audio
        )

        print(
            f"Test RMS: {level:.5f}"
        )

        if level < MIN_RMS:

            print(
                "⚠️ Recording too quiet."
            )

            print(
                "Skipping this test."
            )

            continue

        accepted, score = (
            verifier.verify(
                test_audio
            )
        )

        if score is None:

            print(
                "❌ Could not calculate score."
            )

            continue

        score = float(
            score
        )

        scores.append(
            score
        )

        print()

        print(
            f"Similarity score: "
            f"{score:.4f}"
        )

        print(
            f"Threshold: "
            f"{verifier.threshold:.4f}"
        )

        if accepted:

            print(
                "✅ VOICE VERIFIED"
            )

        else:

            print(
                "❌ VOICE REJECTED"
            )

    # ========================================================
    # ANALYZE
    # ========================================================

    analyze_scores(
        scores,
        verifier.threshold,
    )

    # ========================================================
    # COMPLETE
    # ========================================================

    print()
    print("=" * 64)
    print("                 ENROLLMENT COMPLETE")
    print("=" * 64)
    print()

    print(
        f"Enrollment samples: "
        f"{len(samples)}"
    )

    print(
        f"Verification tests: "
        f"{len(scores)}"
    )

    print(
        f"Profile: "
        f"{OUTPUT_PROFILE}"
    )

    print()


# ============================================================
# ENTRY POINT
# ============================================================

if __name__ == "__main__":
    main()