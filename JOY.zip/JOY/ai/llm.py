from datetime import datetime
import json
import logging
import re
import socket
import subprocess
import time
from typing import Any, Dict, Generator, List, Optional

import config

try:
    import ollama
except ImportError:
    ollama = None

logger = logging.getLogger(__name__)


def is_ollama_running(host: str = "127.0.0.1", port: int = 11434) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(1.0)
        return s.connect_ex((host, port)) == 0


def ensure_ollama_and_model(model_name: str):
    if not is_ollama_running():
        logger.info("Ollama is not running. Starting Ollama service...")
        try:
            creation_flag = getattr(subprocess, "CREATE_NO_WINDOW", 0)
            subprocess.Popen(
                ["ollama", "serve"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                creationflags=creation_flag,
            )

            for _ in range(20):
                time.sleep(0.5)
                if is_ollama_running():
                    logger.info("Ollama service started successfully.")
                    break
        except Exception as e:
            logger.error(f"Failed to start Ollama automatically: {e}")
            return

    if ollama:
        try:
            models_list = ollama.list()
            available_names = [
                m.get("name") or m.get("model") for m in models_list.get("models", [])
            ]

            if not any(model_name in name for name in available_names if name):
                logger.info(f"Model '{model_name}' not found locally. Pulling model...")
                ollama.pull(model_name)
                logger.info(f"Model '{model_name}' pulled successfully.")
        except Exception as e:
            logger.warning(f"Could not verify or pull Ollama model automatically: {e}")


def clean_token(text: str) -> str:
    """Removes markdown artifacts and carriage returns for clean voice delivery."""
    if not text:
        return ""
    return text.replace("*", "").replace("#", "").replace("`", "").replace("\r", "")


class LocalLLM:
    """
    Local LLM Engine powered by Ollama and Phi-4-mini.
    Directly bound to config.LLM_CONFIG with zero in-code default fallbacks.
    """

    def __init__(self):
        # Direct configuration bindings
        self.model_name = config.LLM_CONFIG["model"]
        self.temperature = config.LLM_CONFIG["temperature"]
        self.max_history_turns = config.LLM_CONFIG["max_history_turns"]
        self.base_system_prompt = config.LLM_CONFIG["system_prompt"]

        self.history: List[Dict[str, str]] = []
        ensure_ollama_and_model(self.model_name)
        self._warm_model()

    def _warm_model(self):
        """Load the model once at startup so the first user request avoids model-load latency."""
        if not ollama:
            return
        try:
            ollama.generate(
                model=self.model_name,
                prompt="",
                stream=False,
                options={"num_predict": 1, "temperature": 0.0},
                keep_alive=-1,
            )
            logger.info(f"Ollama model warmed and kept loaded: {self.model_name}")
        except Exception as e:
            logger.warning(f"Could not warm Ollama model: {e}")

    def record_turn(self, user_text: str, assistant_text: str):
        """Allows Tier 1, Tier 2, Tier 3, and Tier 4 to write to conversation memory."""
        if not user_text or not assistant_text:
            return

        self.history.append({"role": "user", "content": user_text.strip()})
        self.history.append({"role": "assistant", "content": assistant_text.strip()})
        self._trim_history()

    def _trim_history(self):
        """Keeps conversation memory strictly within the sliding window."""
        max_messages = self.max_history_turns * 2
        if len(self.history) > max_messages:
            self.history = self.history[-max_messages:]

    def extract_intent(self, text: str) -> Optional[Dict[str, Any]]:
        """
        Tier 2 Intent Extractor (Strict OS Action Schema).
        Extracts system actions and parameters without few-shot examples.
        """
        if not ollama:
            return None

        system_prompt = (
            "You are JOY's OS Intent Extractor. Analyze the user request and output ONLY valid JSON.\n\n"
            "If the request is conversational, a question, general knowledge, temporal/date/time check, "
            'or does not match a supported system action, output: {"action": "none"}\n\n'
            "Supported Actions and Schemas:\n"
            '- "check_battery": Inquiries regarding battery percentage, health, or charging status. (params: none)\n'
            '- "set_volume": Commands adjusting system volume level. (params: "level" as integer 0-100)\n'
            '- "take_screenshot": Commands to capture or screenshot the display. (params: none)\n'
            '- "search_youtube": Commands asking to search, play, or watch something on YouTube. (params: "query" as string)\n'
            '- "search_google": Commands explicitly asking to search Google or lookup something on the web. (params: "query" as string)'
        )

        try:
            response = ollama.chat(
                model=self.model_name,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": text},
                ],
                format="json",
                options={"temperature": 0.0},
            )

            content = response["message"]["content"]
            data = json.loads(content)

            if data.get("action") and data["action"] != "none":
                return data
        except Exception as e:
            logger.error(f"Failed to extract intent via Ollama: {e}")

        return None
    
    def generate_speech_response_stream(
        self, text: str
    ) -> Generator[str, None, None]:
        """Tier 3: Conversational response streaming with system prompt and memory."""
        if not ollama:
            yield "Ollama library is not installed."
            return

        now = datetime.now()
        today_str = now.strftime("%A, %B %d, %Y")
        time_str = now.strftime("%I:%M %p").lstrip("0")

        live_system_prompt = (
            f"{self.base_system_prompt}\n\n"
            "TIER 3 SAFETY BOUNDARY:\n"
            "You are responding in conversational mode only. You do NOT have direct permission to execute, open, "
            "close, launch, kill, minimize, maximize, change, set, or control any application, file, device, "
            "Windows setting, volume, screenshot, browser, or other OS resource from Tier 3.\n"
            "Never claim that you performed an operating-system action unless the user message itself is purely "
            "describing something that already happened. Never invent successful tool execution.\n"
            "If the user's message looks like a command but no deterministic tool handled it, do not guess what "
            "application or action they meant. Say briefly that you did not understand the command and ask them "
            "to repeat it. For example, if the input is a likely speech-recognition error such as 'close calcium', "
            "do not reinterpret it as 'close calculator'.\n"
            "Do not describe an OS action as completed in future or past tense either.\n\n"
            f"[LIVE CONTEXT: Today is {today_str}, and the current time is {time_str}]"
        )

        messages = [{"role": "system", "content": live_system_prompt}]
        if self.history:
            messages.extend(self.history)
        messages.append({"role": "user", "content": text})

        try:
            response = ollama.chat(
                model=self.model_name,
                messages=messages,
                options={
                    "temperature": self.temperature,
                    "num_predict": 96,
                },
                keep_alive=-1,
                stream=True,
            )

            has_started = False

            for chunk in response:
                content = chunk.get("message", {}).get("content", "")
                if not content:
                    continue

                cleaned_token = clean_token(content)

                if not has_started:
                    cleaned_token = cleaned_token.lstrip("\n\r\t ")
                    if cleaned_token:
                        has_started = True
                        yield cleaned_token
                else:
                    cleaned_token = cleaned_token.replace("\n", " ")
                    yield cleaned_token

        except Exception as e:
            logger.error(f"Failed to generate Ollama response stream: {e}")
            yield "Sorry, I had trouble processing that request."

    def generate_tool_reasoning_stream(
        self, text: str, tool_context: str
    ) -> Generator[str, None, None]:
        """Tier 4: Tool-augmented conversational streaming with live telemetry."""
        if not ollama:
            yield "Ollama library is not installed."
            return

        now = datetime.now()
        today_str = now.strftime("%A, %B %d, %Y")
        time_str = now.strftime("%I:%M %p").lstrip("0")

        tool_system_prompt = (
            f"{self.base_system_prompt}\n\n"
            f"[LIVE CONTEXT: Today is {today_str}, and the current time is {time_str}]\n"
            f"[LIVE TELEMETRY]: {tool_context}\n"
            f"Use the telemetry above to answer the user concisely in 1 to 2 spoken sentences."
        )

        messages = [{"role": "system", "content": tool_system_prompt}]
        if self.history:
            messages.extend(self.history)
        messages.append({"role": "user", "content": text})

        try:
            response = ollama.chat(
                model=self.model_name,
                messages=messages,
                options={
                    "temperature": self.temperature,
                    "num_predict": 96,
                },
                keep_alive=-1,
                stream=True,
            )

            has_started = False

            for chunk in response:
                content = chunk.get("message", {}).get("content", "")
                if not content:
                    continue

                cleaned_token = clean_token(content)

                if not has_started:
                    cleaned_token = cleaned_token.lstrip("\n\r\t ")
                    if cleaned_token:
                        has_started = True
                        yield cleaned_token
                else:
                    cleaned_token = cleaned_token.replace("\n", " ")
                    yield cleaned_token

        except Exception as e:
            logger.error(f"Failed to generate Ollama tool reasoning stream: {e}")
            yield "Sorry, I had trouble processing that request."