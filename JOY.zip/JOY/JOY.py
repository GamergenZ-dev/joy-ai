import os
from pathlib import Path
import sys

# Ensure project root is prioritized in sys.path for direct execution
ROOT_DIR = Path(__file__).resolve().parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from utils.logger import setup_logger

# Initialize logging configuration before importing heavy submodules
logger = setup_logger()

from core.assistant import Assistant


# ============================================================
# APPLICATION ENTRY POINT
# ============================================================
def main() -> None:
    """Instantiates and executes the JOY AI Assistant lifecycle."""
    try:
        assistant = Assistant()
        assistant.run()
    except KeyboardInterrupt:
        logger.info("JOY Assistant Terminated by user.")
        sys.exit(0)
    except Exception as e:
        logger.critical(f"Unhandled fatal exception in JOY: {e}", exc_info=True)
        sys.exit(1)


if __name__ == "__main__":
    main()