import os
from pathlib import Path

# ==============================================================================
# Speech-To-Text (STT)
# ==============================================================================

STT_MODEL = "UsefulSensors/moonshine-streaming-medium"
STT_MODEL_PATH = None  # None uses default Hugging Face cache
STT_SAMPLE_RATE = 16000
STT_BLOCK_SIZE = 320
STT_ENERGY = 0.014
STT_SILENCE = 0.30
STT_PARTIAL_INTERVAL = 0.22
STT_PREROLL = 25

STT_CONFIG = {
    "model": STT_MODEL,
    "model_path": STT_MODEL_PATH,
    "sample_rate": STT_SAMPLE_RATE,
    "block_size": STT_BLOCK_SIZE,
    "energy_threshold": STT_ENERGY,
    "silence_duration": STT_SILENCE,
    "partial_interval": STT_PARTIAL_INTERVAL,
    "preroll_blocks": STT_PREROLL,
}

# ==============================================================================
# Local LLM (Ollama - Phi-4-mini)
# ==============================================================================

OLLAMA_MODEL = "phi4-mini:latest"
LLM_TEMPERATURE = 0.3
LLM_MAX_HISTORY_TURNS = 10

LLM_SYSTEM_PROMPT = (
    "You are JOY, an ultra-fast, intelligent, and highly capable personal AI voice assistant.\n\n"
    "Core Directives:\n"
    "1. Voice-Optimized Output: You speak directly through a real-time text-to-speech engine. "
    "NEVER use markdown formatting (*, **, #, _, `), bullet points, numbered lists, emojis, code blocks, or special symbols. "
    "Speak strictly in clean, natural prose.\n"
    "2. Conciseness: Keep everyday answers brief (1 to 3 sentences). Only elaborate when explicitly asked.\n"
    "3. Direct Delivery: Never use opening conversational filler like 'Certainly!', 'Sure!', 'As an AI...', or 'Here is the info:'. Answer immediately.\n"
    "4. Spoken Clarity: Write numbers, calculations, and dates in speakable, natural phrasing.\n"
    "5. Persona: Confident, sharp, authentic, and helpful.\n"
    "6. Action Integrity: Never claim that you opened, closed, launched, killed, changed, or controlled a system resource. "
    "Only validated deterministic/tool layers may execute system actions. In ordinary conversation, describe yourself as "
    "unable to perform an action when no tool has actually executed it."
)

LLM_CONFIG = {
    "model": OLLAMA_MODEL,
    "temperature": LLM_TEMPERATURE,
    "max_history_turns": LLM_MAX_HISTORY_TURNS,
    "system_prompt": LLM_SYSTEM_PROMPT,
}

# ==============================================================================
# Text-To-Speech (TTS)
# ==============================================================================

TTS_RATE = 168
TTS_VOLUME = 1.0
TTS_VOICE_INDEX = 0

# Streaming queue & worker
TTS_QUEUE_MAXSIZE = 64
TTS_WORKER_TIMEOUT = 0.05
TTS_SHUTDOWN_JOIN_TIMEOUT = 2.0

# Chunking thresholds for streaming playback
TTS_FIRST_CHUNK_WORDS = 3
TTS_FIRST_SENTENCE_MIN_WORDS = 2
TTS_NEXT_CHUNK_WORDS = 8
TTS_NEXT_SENTENCE_MIN_WORDS = 3
TTS_SOFT_BOUNDARY_ENABLED = True
TTS_SOFT_BOUNDARY_MIN_WORDS = 6

# SAPI rate & volume mapping (-10 to +10 range)
TTS_SAPI_RATE_OFFSET = 165.0
TTS_SAPI_RATE_SCALE = 15.0
TTS_SAPI_RATE_MIN = -10
TTS_SAPI_RATE_MAX = 10
TTS_SAPI_VOLUME_MIN = 0
TTS_SAPI_VOLUME_MAX = 100

TTS_CONFIG = {
    "rate": TTS_RATE,
    "volume": TTS_VOLUME,
    "voice_index": TTS_VOICE_INDEX,
    "queue_maxsize": TTS_QUEUE_MAXSIZE,
    "worker_timeout": TTS_WORKER_TIMEOUT,
    "first_chunk_words": TTS_FIRST_CHUNK_WORDS,
    "first_sentence_min_words": TTS_FIRST_SENTENCE_MIN_WORDS,
    "next_chunk_words": TTS_NEXT_CHUNK_WORDS,
    "next_sentence_min_words": TTS_NEXT_SENTENCE_MIN_WORDS,
    "soft_boundary_enabled": TTS_SOFT_BOUNDARY_ENABLED,
    "soft_boundary_min_words": TTS_SOFT_BOUNDARY_MIN_WORDS,
    "sapi_rate_offset": TTS_SAPI_RATE_OFFSET,
    "sapi_rate_scale": TTS_SAPI_RATE_SCALE,
    "sapi_rate_min": TTS_SAPI_RATE_MIN,
    "sapi_rate_max": TTS_SAPI_RATE_MAX,
    "sapi_volume_min": TTS_SAPI_VOLUME_MIN,
    "sapi_volume_max": TTS_SAPI_VOLUME_MAX,
    "shutdown_join_timeout": TTS_SHUTDOWN_JOIN_TIMEOUT,
}

# ==============================================================================
# Wake & Sleep State
# ==============================================================================

START_IN_SLEEP_MODE = True

WAKE_COMMANDS = (
    "hey joy",
    "hello joy",
    "joy",
    "hi joy",
    "what are you doing joy",
)

SLEEP_COMMANDS = (
    "sleep joy",
    "go to sleep",
    "sleep",
    "stop listening",
)

WAKE_CONFIG = {
    "start_in_sleep": START_IN_SLEEP_MODE,
    "wake_commands": WAKE_COMMANDS,
    "sleep_commands": SLEEP_COMMANDS,
    "sleep_cooldown": 0.20,
}